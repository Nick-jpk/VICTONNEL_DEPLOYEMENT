# WhatsApp Group Bot (TypeScript)

Minimal WhatsApp bot using `whatsapp-web.js` with a single `!ping` command.

Focus: reliable session persistence via Mongo RemoteAuth, single group scope, Render-friendly deploy.

## Repo Structure

- `src/index.ts` – App entry; boots WhatsApp client and health server.
- `src/services/whatsapp.ts` – Client with Mongo `RemoteAuth` session storage.
- `src/services/http.ts` – Tiny HTTP server for Render health (`/health`).
- `src/commands/` – Command router and `!ping` handler.
- `src/config/index.ts` – Env/config (`PORT`, `SESSION_DIR`, `ALLOWED_GROUP_ID`, `MONGODB_URI`, `MONGODB_DB`).
- `src/db/mongo.ts` – MongoDB connection helper (for future features).
- Session persists in MongoDB (no Render Disk required).

## Prereqs

- Node.js 18+
- A throwaway WhatsApp number
- A MongoDB URI (e.g., MongoDB Atlas) if you want DB connected at boot

## Local Setup (first login)

1. Copy env and set the target group:

   ```bash
   cp .env.example .env
   # Set ALLOWED_GROUP_ID to your group id (e.g. 1234-5678@g.us)
   ```

   Tip: you can deploy first and temporarily leave `ALLOWED_GROUP_ID` blank to respond anywhere, then capture your group id from logs and lock it down.

2. Install and run:

   ```bash
   npm ci
   npm run dev
   ```

3. Scan the QR displayed in the terminal. The session files are written to `storage/session/`.

4. Test in your group with `!ping` (the bot replies `pong`).

## Render Deploy (Web Service + Disk)

This project includes `render.yaml`. Using the Render Dashboard:

1. New Web Service → Use this repo; select plan `Free`.
2. Add a Disk named `bot-storage`, mount path `/storage`, size 2 GB.
3. Build Command: `npm ci && npm run build`
4. Start Command: `npm start`
5. Set env vars:
   - `PORT=3000`
   - `ALLOWED_GROUP_ID=1234567890-123456789@g.us` (your group id)
   - `MONGODB_URI=<your Atlas connection string>`
   - `MONGODB_DB=whatsappbot`

### First-time Login on Render

Login on Render

- On first deploy, the service logs will print a QR. If your logs do not render the QR blocks, copy the raw QR string from logs and paste it into any QR generator app to scan with WhatsApp. The session is stored in Mongo and will persist across restarts and hibernation.

The health endpoint is served on `/health` to satisfy Web Service checks.

## Notes

- The bot only responds in the configured `ALLOWED_GROUP_ID`. Leave empty during initial testing if you want it to respond anywhere; set it before going live.
- Session persistence uses Mongo RemoteAuth (no Render Disk).
- MongoDB is connected at boot if `MONGODB_URI` is provided; game summaries and user stats are stored.

## Scripts

- `npm run dev` – Watch mode with TSX
- `npm run build` – Compile TypeScript to `dist/`
- `npm start` – Run compiled app
  
