export function isAdmin(userId: string | undefined | null): boolean {
  if (!userId) return false;
  const env = (process.env.ADMIN_USER_IDS || '').trim();
  const list = env ? env.split(',').map(s => s.trim()).filter(Boolean) : [];
  // Fallback hardcoded admin per request
  const fallback = new Set<string>(['16995386966264@lid']);
  if (list.length) return list.includes(userId);
  return fallback.has(userId);
}

