import qrcode from 'qrcode-terminal';
import makeWASocket, {
  DisconnectReason,
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
  WASocket,
  proto,
} from '@whiskeysockets/baileys';
import { logger } from '../utils/logger.js';
import { config } from '../config/index.js';
import NodeCache from 'node-cache';

export type Message = {
  body: string;
  from: string; // remoteJid
  author?: string; // participant for groups
  reply: (text: string) => Promise<void>;
  getChat: () => Promise<{ id: { _serialized: string }; isGroup: boolean; name?: string; sendMessage: (text: string) => Promise<void> }>;
  getContact: () => Promise<{ pushname?: string; name?: string; id?: { _serialized: string } }>;
};

export async function createClient(): Promise<WASocket> {
  const { state, saveCreds } = await useMultiFileAuthState(process.env.BAILEYS_AUTH_DIR || './baileys_auth');
  const { version } = await fetchLatestBaileysVersion();

  const retryCache = new NodeCache({ stdTTL: 60, checkperiod: 120 });

  const sock = makeWASocket({
    version,
    auth: state,
    printQRInTerminal: false,
    browser: ['Bot', 'Chrome', '1.0.0'],
    syncFullHistory: false,
    msgRetryCounterCache: retryCache,
    markOnlineOnConnect: false,
  });

  sock.ev.on('creds.update', saveCreds);

  sock.ev.on('connection.update', (u) => {
    const { connection, lastDisconnect, qr } = u;
    if (qr) {
      logger.info('QR received. Scan to log in.');
      if (process.stdout.isTTY) qrcode.generate(qr, { small: true });
      else { logger.info('Not a TTY. Copy the QR string into a QR generator app.'); logger.info(qr); }
    }
    if (connection === 'open') logger.info('WhatsApp client ready');
    if (connection === 'close') {
      const code = (lastDisconnect?.error as any)?.output?.statusCode || (lastDisconnect?.error as any)?.code;
      logger.warn({ code }, 'WhatsApp disconnected');
      if (code !== DisconnectReason.loggedOut) {
        // rely on external manager (systemd) to restart; or attempt to reconnect
        setTimeout(() => createClient().catch(() => {}), 5_000);
      }
    }
  });

  return sock as unknown as WASocket;
}

export type MessageHandler = (msg: Message) => Promise<void> | void;

export function onMessage(sock: WASocket, handler: MessageHandler) {
  sock.ev.on('messages.upsert', async (m) => {
    if (m.type !== 'notify') return;
    for (const msg of m.messages) {
      const remoteJid = msg.key.remoteJid || '';
      const fromMe = !!msg.key.fromMe;
      const isGroup = remoteJid.endsWith('@g.us');
      const participant = msg.key.participant || undefined;
      if (fromMe) continue;
      const text = getMessageText(msg);
      const wrapper: Message = {
        body: text,
        from: remoteJid,
        author: participant,
        reply: async (text: string) => { await sock.sendMessage(remoteJid, { text }); },
        getChat: async () => {
          let name: string | undefined;
          try {
            if (isGroup) {
              const md = await sock.groupMetadata(remoteJid);
              name = md.subject;
            } else {
              const c = sock?.user || undefined;
              name = c?.name;
            }
          } catch {}
          return {
            id: { _serialized: remoteJid },
            isGroup,
            name,
            sendMessage: async (text: string) => { await sock.sendMessage(remoteJid, { text }); },
          };
        },
        getContact: async () => {
          const pushname = (msg.pushName as string) || undefined;
          return { pushname, name: pushname, id: { _serialized: participant || remoteJid } };
        },
      };
      try { await handler(wrapper); } catch (e) { logger.warn({ e }, 'handler failed'); }
    }
  });
}

function getMessageText(m: proto.IWebMessageInfo): string {
  const msg = m.message || {};
  if ((msg as any).conversation) return (msg as any).conversation as string;
  if (msg.extendedTextMessage?.text) return msg.extendedTextMessage.text as string;
  if (msg.imageMessage?.caption) return msg.imageMessage.caption as string;
  if (msg.videoMessage?.caption) return msg.videoMessage.caption as string;
  return '';
}
