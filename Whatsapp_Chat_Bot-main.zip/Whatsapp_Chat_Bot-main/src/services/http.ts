import http from 'node:http';
import { config } from '../config/index.js';
import { logger } from '../utils/logger.js';

export function startHttpServer() {
  const server = http.createServer((req, res) => {
    if (req.url === '/health') {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ok: true }));
      return;
    }
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    res.end('WhatsApp Bot running');
  });

  server.listen(config.port, () => {
    logger.info({ port: config.port }, 'HTTP health server listening');
  });
}

