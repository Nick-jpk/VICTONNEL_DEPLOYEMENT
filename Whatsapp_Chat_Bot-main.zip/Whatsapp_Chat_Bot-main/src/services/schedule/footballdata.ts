type TeamId = 57 | 61 | 64 | 65 | 66 | 81 | 86;

const TEAM_IDS: Record<string, TeamId> = {
  'Arsenal': 57,
  'Chelsea': 61,
  'Liverpool': 64,
  'Manchester City': 65,
  'Manchester United': 66,
  'Barcelona': 81,
  'Real Madrid': 86,
};

const BASE = 'https://api.football-data.org/v4';

// Simple in-memory cache to avoid hitting rate limits (10/min on free)
const cache = new Map<string, { at: number; value: string }>();
const CACHE_MS = 60_000; // 60s

function fmtDatePKT(iso: string): string {
  try {
    const d = new Date(iso);
    const datePart = new Intl.DateTimeFormat('en-GB', {
      timeZone: 'Asia/Karachi',
      weekday: 'short', day: '2-digit', month: 'short',
    }).format(d);
    const timePart = new Intl.DateTimeFormat('en-US', {
      timeZone: 'Asia/Karachi',
      hour: 'numeric', minute: '2-digit', hour12: true,
    }).format(d).toLowerCase();
    return `${datePart}, ${timePart} Pak Time`;
  } catch {
    return iso;
  }
}

async function fetchJSON(path: string, params?: Record<string, string | number>) {
  const token = process.env.FOOTBALL_DATA_TOKEN || '';
  if (!token) throw new Error('FOOTBALL_DATA_TOKEN not set');
  const url = new URL(`${BASE}${path}`);
  if (params) {
    Object.entries(params).forEach(([k, v]) => url.searchParams.set(k, String(v)));
  }
  const res = await fetch(url.toString(), { headers: { 'X-Auth-Token': token } });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

async function nextMatchForTeam(teamId: number): Promise<{ home: string; away: string; iso: string; comp?: string } | null> {
  // Try SCHEDULED next match
  try {
    const data = await fetchJSON(`/teams/${teamId}/matches`, { status: 'SCHEDULED', limit: 1 });
    const m = data?.matches?.[0];
    if (m?.utcDate) {
      return { home: m.homeTeam?.name, away: m.awayTeam?.name, iso: m.utcDate, comp: m.competition?.name };
    }
  } catch {}
  // Fallback: TIMED (older status)
  try {
    const data = await fetchJSON(`/teams/${teamId}/matches`, { status: 'TIMED', limit: 1 });
    const m = data?.matches?.[0];
    if (m?.utcDate) {
      return { home: m.homeTeam?.name, away: m.awayTeam?.name, iso: m.utcDate, comp: m.competition?.name };
    }
  } catch {}
  // Fallback: dateFrom today → next
  try {
    const today = new Date().toISOString().slice(0, 10);
    const data = await fetchJSON(`/teams/${teamId}/matches`, { dateFrom: today, limit: 1 });
    const m = data?.matches?.[0];
    if (m?.utcDate) {
      return { home: m.homeTeam?.name, away: m.awayTeam?.name, iso: m.utcDate, comp: m.competition?.name };
    }
  } catch {}
  return null;
}

export async function getNextFixturesFD(): Promise<string> {
  const cacheKey = 'footy:next';
  const now = Date.now();
  const cached = cache.get(cacheKey);
  if (cached && now - cached.at < CACHE_MS) return cached.value;

  const entries = Object.entries(TEAM_IDS);
  const lines: string[] = [];
  for (const [name, id] of entries) {
    const match = await nextMatchForTeam(id);
    if (!match) {
      lines.push(`${name}: no upcoming match found`);
      continue;
    }
    const when = fmtDatePKT(match.iso);
    const comp = match.comp ? ` (${match.comp})` : '';
    lines.push(`${match.home} vs ${match.away} — ${when}${comp}`);
  }
  const out = lines.join('\n\n');
  cache.set(cacheKey, { at: now, value: out });
  return out;
}
