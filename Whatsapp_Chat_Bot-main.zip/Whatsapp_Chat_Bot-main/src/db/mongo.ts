import { MongoClient, Db } from 'mongodb';
import { config } from '../config/index.js';
import { logger } from '../utils/logger.js';

let client: MongoClient | null = null;
let db: Db | null = null;

export async function connectMongo() {
  if (db) return db;
  if (!config.mongoUri) {
    logger.warn('MONGODB_URI not set; skipping DB connection');
    return null as unknown as Db;
  }
  client = new MongoClient(config.mongoUri, {
    maxPoolSize: 3,
    minPoolSize: 0,
    serverSelectionTimeoutMS: 5000,
  });
  await client.connect();
  db = client.db(config.mongoDb);
  logger.info({ db: config.mongoDb }, 'Connected to MongoDB');
  return db;
}

export function getDb(): Db {
  if (!db) {
    throw new Error('MongoDB not connected. Call connectMongo() first.');
  }
  return db;
}

export async function closeMongo() {
  if (client) {
    await client.close();
    client = null;
    db = null;
  }
}
