import type { Message } from '../services/whatsapp.js';
import { playSlots } from '../modules/casino/slots.js';

export async function handleCasinoHelp(msg: Message) {
  const lines = [
    '🎰 Casino:',
    '!slots — Spin (default $50). Payouts: 2x for 2 match, 5x for 3 match.',
    '!roulette — Bet on 🔴/⚫, odd/even (min $10). (coming soon)',
    '!blackjack — Join a one-round table with hit/stand (coming soon)',
    '!jackpot — Group pot, random winner (coming soon)',
    '!rroulette — Russian roulette, max 6 players (coming soon)',
  ];
  await msg.reply(lines.join('\n'));
}

export async function handleSlots(msg: Message) {
  const body = (msg.body || '').trim();
  const m = body.match(/^!slots\s*(\d+)?/i);
  const bet = m && m[1] ? parseInt(m[1], 10) : undefined;
  await playSlots(msg, bet);
}

