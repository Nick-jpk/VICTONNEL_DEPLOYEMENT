import type { Message } from '../services/whatsapp.js';
import { getDb } from '../db/mongo.js';
import { rankName } from '../utils/ranks.js';

export async function handleMyStats(msg: Message) {
  try {
    const db = getDb();
    const userId = (msg.author || msg.from) as string;
    const doc = await db.collection('user_stats').findOne(
      { userId },
      { projection: { elo: 1, gamesPlayed: 1, wins: 1, lastSeenName: 1 } }
    );
    if (!doc) {
      await msg.reply('No stats yet. Play a trivia game to get ranked!');
      return;
    }
    const name = doc.lastSeenName || userId;
    const elo = typeof doc.elo === 'number' ? doc.elo : 0;
    const gp = typeof doc.gamesPlayed === 'number' ? doc.gamesPlayed : 0;
    const wins = typeof doc.wins === 'number' ? doc.wins : 0;
    const rank = rankName(elo);
    const lines = [
      `Your Stats:`,
      `${name}`,
      `Rank: ${rank}`,
      `Elo: ${elo}`,
      `Games: ${gp} (wins: ${wins})`,
    ];
    await msg.reply(lines.join('\n'));
  } catch {
    await msg.reply('Stats not available right now.');
  }
}
