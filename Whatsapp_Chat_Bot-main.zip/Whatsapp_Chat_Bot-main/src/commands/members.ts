import type { Message } from '../services/whatsapp.js';
import type { WASocket } from '@whiskeysockets/baileys';

export async function handleMembers(client: WASocket, msg: Message) {
  const chat = await msg.getChat();
  if (!chat.isGroup) {
    await msg.reply('This command only works in a group chat.');
    return;
  }
  const md = await client.groupMetadata(chat.id._serialized);
  const participants = md.participants || [];
  if (!participants.length) {
    await msg.reply('No participants found.');
    return;
  }

  const lines: string[] = [];
  lines.push(`Group members (${participants.length}):`);
  for (const p of participants) {
    const jid = (p as any).id || ((p as any).id?._serialized) || (p as any);
    const name = (p?.notify || p?.name || '').trim();
    lines.push(name ? `${jid} — ${name}` : `${jid}`);
  }

  // WhatsApp messages have a size limit; slice if excessively long
  const text = lines.join('\n');
  if (text.length <= 6000) {
    await msg.reply(text);
  } else {
    // Fallback: send only JIDs if long
    const idsOnly = [
      `Group member IDs (${participants.length}):`,
      ...participants.map((p: any) => (p.id || (p.id?._serialized) || p)),
    ].join('\n');
    await msg.reply(idsOnly);
  }
}
