import type { WASocket } from '@whiskeysockets/baileys';
import type { Message } from '../services/whatsapp.js';
import { mentionTag } from '../modules/tags/index.js';

export async function handleFifaGang(client: WASocket, msg: Message) {
  await mentionTag(client, msg, 'fifagang');
}

export async function handleRankedSquad(client: WASocket, msg: Message) {
  await mentionTag(client, msg, 'rankedsquad');
}
