import type { Message } from '../services/whatsapp.js';

export async function handleRacism(msg: Message) {
  await msg.reply('No to racism, no to incest.');
}

