import type { WASocket } from '@whiskeysockets/baileys';
import type { Message } from '../services/whatsapp.js';
import { getNextFixturesFD } from '../services/schedule/footballdata.js';

export async function handleScheduleFooty(_client: WASocket, msg: Message) {
  try {
    const text = await getNextFixturesFD();
    await msg.reply(text);
  } catch (e: any) {
    await msg.reply('Football schedule unavailable right now.');
  }
}

// F1 and UFC removed for now
