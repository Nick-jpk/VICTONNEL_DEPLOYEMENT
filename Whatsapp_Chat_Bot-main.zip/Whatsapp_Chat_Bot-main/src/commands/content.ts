import type { Message } from '../services/whatsapp.js';
import fs from 'node:fs';
import path from 'node:path';

type TweetMedia = { media_key: string; type: string; url?: string; preview_image_url?: string };

// Simple in-process cooldown to avoid burst 429s when users spam !content
let lastApiAttemptMs = 0;
const API_COOLDOWN_MS = 60 * 1000; // 60s
const IMAGE_DIR = 'storage/content';
const IMAGE_PATH = `${IMAGE_DIR}/latest.jpg`; // legacy single-file path (kept for backward compat)

function readCache(p: string): any | null {
  try {
    if (!fs.existsSync(p)) return null;
    const txt = fs.readFileSync(p, 'utf8');
    return JSON.parse(txt);
  } catch {
    return null;
  }
}

function writeCache(p: string, data: any) {
  try {
    const dir = path.dirname(p);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(p, JSON.stringify(data, null, 2));
  } catch {}
}

async function fetchJson(url: string, token: string) {
  const res = await fetch(url, {
    headers: { Authorization: `Bearer ${token}` },
  });
  if (!res.ok) {
    const body = await res.text().catch(() => '');
    throw new Error(`X API ${res.status}: ${body.slice(0, 200)}`);
  }
  return res.json();
}

export async function sendLatestContentToChat(client: any, chatId: string) {
  const USERNAME = ((process.env.CONTENT_USERNAME || 'easysbc_alerts').trim().replace(/^@/, ''));
  const token = (process.env.TWITTER_BEARER_TOKEN || '').trim();
  if (!token) {
    throw new Error('Twitter API not configured (set TWITTER_BEARER_TOKEN)');
  }

  // Send ALL cached images from disk (no API calls)
  if (fs.existsSync(IMAGE_DIR)) {
    const files = fs.readdirSync(IMAGE_DIR)
      .filter((f: string) => /\.(jpg|jpeg|png)$/i.test(f))
      .sort();
    if (files.length > 0) {
      const cache = readCache('storage/content_cache.json') || {};
      for (const f of files) {
        const filePath = path.join(IMAGE_DIR, f);
        const buf = fs.readFileSync(filePath);
        const meta = (cache.images || []).find((i: any) => i.path === filePath);
        const caption = meta?.caption || cache.caption || `@${USERNAME}`;
        await client.sendMessage(chatId, { image: buf, caption });
      }
      return;
    }
  }

  // No cached images available
  await client.sendMessage(chatId, { text: 'No cached content available yet.' });
}

export async function handleContent(client: any, msg: Message) {
  const USERNAME = ((process.env.CONTENT_USERNAME || 'easysbc_alerts').trim().replace(/^@/, ''));
  const token = (process.env.TWITTER_BEARER_TOKEN || '').trim();
  if (!token) {
    await msg.reply('Twitter API not configured. Set TWITTER_BEARER_TOKEN in .env');
    return;
  }
  const chat = await msg.getChat();
  const chatId = (chat as any).id?._serialized as string;
  // Serve all cached images; never hit API here
  await sendLatestContentToChat(client, chatId);
}

// Refresh the content cache by fetching all photo tweets in the last windowMinutes before now
export async function refreshContentCache(windowMinutes = 10): Promise<number> {
  const USERNAME = ((process.env.CONTENT_USERNAME || 'easysbc_alerts').trim().replace(/^@/, ''));
  const token = (process.env.TWITTER_BEARER_TOKEN || '').trim();
  if (!token) throw new Error('Twitter API not configured (set TWITTER_BEARER_TOKEN)');

  // Resolve user id
  const userResp = await fetchJson(`https://api.twitter.com/2/users/by/username/${USERNAME}`, token);
  const userId = userResp?.data?.id as string | undefined;
  if (!userId) throw new Error('User not found');

  // Compute time window: last N minutes relative to now
  const end = new Date();
  const start = new Date(end.getTime() - windowMinutes * 60 * 1000);
  const endIso = end.toISOString();
  const startIso = start.toISOString();

  // Fetch tweets in window with media expansions
  const params = new URLSearchParams({
    exclude: 'retweets,replies',
    expansions: 'attachments.media_keys',
    'media.fields': 'url,preview_image_url,type',
    'tweet.fields': 'created_at',
    'start_time': startIso,
    'end_time': endIso,
    max_results: '25',
  });
  const tw = await fetchJson(`https://api.twitter.com/2/users/${userId}/tweets?${params.toString()}`, token);
  const tweets = (tw?.data || []) as Array<any>;
  const media = new Map<string, TweetMedia>();
  for (const m of (tw?.includes?.media || []) as TweetMedia[]) media.set(m.media_key, m);

  // Collect all photo media from tweets (preserve chronological order)
  const items: Array<{ url: string; caption: string; tweetId: string; created_at?: string } > = [];
  for (const t of tweets) {
    const keys: string[] = t?.attachments?.media_keys || [];
    for (const k of keys) {
      const m = media.get(k);
      if (m && m.type === 'photo' && m.url) {
        items.push({ url: m.url, caption: (t.text || '').trim(), tweetId: t.id, created_at: t.created_at });
      }
    }
  }

  // Clear folder
  if (fs.existsSync(IMAGE_DIR)) {
    for (const f of fs.readdirSync(IMAGE_DIR)) {
      try { fs.unlinkSync(path.join(IMAGE_DIR, f)); } catch {}
    }
  } else {
    fs.mkdirSync(IMAGE_DIR, { recursive: true });
  }

  // Download all images to disk
  const imagesMeta: any[] = [];
  let idx = 1;
  for (const it of items) {
    try {
      const r = await fetch(it.url);
      if (!r.ok) continue;
      const arr = await r.arrayBuffer();
      const buf = Buffer.from(arr);
      const name = String(idx).padStart(2, '0') + '.jpg';
      const filePath = path.join(IMAGE_DIR, name);
      fs.writeFileSync(filePath, buf);
      imagesMeta.push({ path: filePath, url: it.url, caption: it.caption, tweetId: it.tweetId, created_at: it.created_at });
      idx += 1;
    } catch {}
  }

  // Write metadata cache
  writeCache('storage/content_cache.json', {
    username: USERNAME,
    t: Date.now(),
    images: imagesMeta,
  });

  return imagesMeta.length;
}
