import type { Message } from '../services/whatsapp.js';
import { getDb } from '../db/mongo.js';
import { rankName } from '../utils/ranks.js';

export async function handleRank(msg: Message) {
  try {
    const db = getDb();
    const users = await db
      .collection('user_stats')
      .find({ gamesPlayed: { $gt: 0 } }, { projection: { userId: 1, elo: 1, gamesPlayed: 1, lastSeenName: 1 } })
      .sort({ elo: -1 })
      .limit(50)
      .toArray();

    if (!users.length) {
      await msg.reply('No ranked players yet. Play a trivia game to get started!');
      return;
    }

    const lines: string[] = [];
    lines.push('Current Rankings:');
    let idx = 1;
    let insertedGap = false;
    for (const u of users) {
      const name = u.lastSeenName || u.userId;
      const elo = typeof u.elo === 'number' ? u.elo : 0;
      const gp = typeof u.gamesPlayed === 'number' ? u.gamesPlayed : 0;
      if (!insertedGap && elo === 0 && idx > 1) {
        lines.push(''); // spacing between >0 and 0 elo users
        insertedGap = true;
      }
      lines.push(`${idx}) ${name} — ${rankName(elo)} — ${elo} (${gp})`);
      idx += 1;
    }

    await msg.reply(lines.join('\n'));
  } catch (err) {
    await msg.reply('Ranking not available right now.');
  }
}
