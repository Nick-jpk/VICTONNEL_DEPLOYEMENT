import type { Message } from '../services/whatsapp.js';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);

type Quote = { id: string; author: string; text: string; source?: string; tags?: string[] };

export async function handleQotd(msg: Message) {
  let quotes: Quote[] = [];
  try {
    quotes = require('../data/quotes/quotes.json') as Quote[];
  } catch {
    // no dataset yet
  }
  if (!Array.isArray(quotes) || quotes.length === 0) {
    await msg.reply('No quotes available yet.');
    return;
  }
  const q = quotes[Math.floor(Math.random() * quotes.length)];
  const line = `${q.author}: ${q.text}`;
  await msg.reply(line);
}

