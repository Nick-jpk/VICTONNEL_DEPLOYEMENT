import type { Message } from '../services/whatsapp.js';

function formatUptime(seconds: number): string {
  const s = Math.floor(seconds % 60);
  const m = Math.floor((seconds / 60) % 60);
  const h = Math.floor((seconds / 3600) % 24);
  const d = Math.floor(seconds / 86400);
  const parts: string[] = [];
  if (d) parts.push(`${d}d`);
  if (h || d) parts.push(`${h}h`);
  if (m || h || d) parts.push(`${m}m`);
  parts.push(`${s}s`);
  return parts.join(' ');
}

export async function handleUptime(msg: Message) {
  const up = process.uptime();
  const text = `Uptime: ${formatUptime(up)}`;
  await msg.reply(text);
}
