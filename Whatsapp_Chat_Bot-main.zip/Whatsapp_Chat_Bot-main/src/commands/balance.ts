import type { Message } from '../services/whatsapp.js';
import { getDb } from '../db/mongo.js';

export async function handleBalance(msg: Message) {
  const userId = (msg.author || msg.from) as string;
  try {
    const db = getDb();
    const doc = await db
      .collection('user_stats')
      .findOne({ userId }, { projection: { balance: 1, lastSeenName: 1 } });
    const bal = typeof doc?.balance === 'number' ? doc!.balance : 500;
    await msg.reply(`Balance: $${bal}`);
  } catch {
    await msg.reply('Balance unavailable right now.');
  }
}
