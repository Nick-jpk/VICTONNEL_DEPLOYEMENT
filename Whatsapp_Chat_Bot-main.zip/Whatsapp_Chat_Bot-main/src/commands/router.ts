import type { Message } from '../services/whatsapp.js';
import { handlePing } from './ping.js';
import { handleChatId } from './chatid.js';
import { startTrivia, isTriviaActive } from '../modules/trivia/index.js';
import { handleRank } from './rank.js';
import { handleMyStats } from './mystats.js';
import { handleHelp } from './help.js';
import { handleFifaGang, handleRankedSquad } from './tags.js';
import { handleWhoAmI } from './whoami.js';
import { handleMembers } from './members.js';
import { handleScheduleFooty } from './schedule.js';
import { handleUptime } from './uptime.js';
import { startCoinflip } from '../modules/coinflip/index.js';
import { handleBalance } from './balance.js';
import { isCoinflipActive } from '../modules/coinflip/index.js';
import { startBeg, handleGive, isBegActive, cancelBeg } from '../modules/beg/index.js';
import { handleSlots } from './casino.js';
import { startRoulette } from '../modules/casino/manager.js';
import { startBlackjack } from '../modules/casino/manager.js';
import { startJackpot } from '../modules/casino/manager.js';
import { startRroulette } from '../modules/casino/manager.js';
import { handleQotd } from './qotd.js';
import { handleRacism } from './racism.js';
import { handleContent } from './content.js';

// No per-user rate limit

export async function routeCommand(client: any, msg: Message) {
  const body = (msg.body || '').trim();
  if (!body.startsWith('!')) return;

  const [cmd] = body.slice(1).split(/\s+/);
  // No per-user rate limit
  // Reduce CPU/latency: ignore all commands while trivia is active in this chat
  try {
    const chat = await msg.getChat();
    const chatId = (chat as any).id?._serialized as string;
    if (isTriviaActive(chatId) || isCoinflipActive(chatId)) {
      // Optionally allow !help, but per request, ignore all during games
      return;
    }
  } catch {}
  switch (cmd.toLowerCase()) {
    case 'ping':
      await handlePing(msg);
      break;
    case 'chatid':
      await handleChatId(msg);
      break;
    case 'trivia':
      await startTrivia(msg);
      break;
    case 'rank':
      await handleRank(msg);
      break;
    case 'mystats':
      await handleMyStats(msg);
      break;
    case 'help':
      await handleHelp(msg);
      break;
    case 'uptime':
      await handleUptime(msg);
      break;
    case 'slots':
      await handleSlots(msg);
      break;
    case 'roulette':
      await startRoulette(msg);
      break;
    case 'blackjack':
      await startBlackjack(msg);
      break;
    case 'jackpot':
      await startJackpot(msg);
      break;
    case 'rroulette':
      await startRroulette(msg);
      break;
    case 'qotd':
      await handleQotd(msg);
      break;
    case 'racism':
      await handleRacism(msg);
      break;
    case 'content':
      await handleContent(client, msg);
      break;
    case 'coinflip':
      // Cancel any beg in progress
      try {
        const chat = await msg.getChat();
        cancelBeg((chat as any).id?._serialized as string);
      } catch {}
      await startCoinflip(msg);
      break;
    case 'balance':
      await handleBalance(msg);
      break;
    case 'beg':
      await startBeg(msg);
      break;
    case 'give':
      await handleGive(msg);
      break;
    case 'schedule':
      await handleScheduleFooty(client, msg);
      break;
    case 'fifagang':
      await handleFifaGang(client, msg);
      break;
    case 'rankedsquad':
      await handleRankedSquad(client, msg);
      break;
    case 'whoami':
      await handleWhoAmI(msg);
      break;
    case 'members':
      await handleMembers(client, msg);
      break;
    default:
      // Ignore unknown commands for MVP
      break;
  }
}
