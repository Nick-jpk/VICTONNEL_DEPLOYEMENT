import type { Message } from '../services/whatsapp.js';

export async function handleChatId(msg: Message) {
  const chat = await msg.getChat();
  const id = (chat as any).id?._serialized || 'unknown';
  const name = (chat as any).name || (chat as any).formattedTitle || '';
  const isGroup = (chat as any).isGroup === true;
  let text = `chatId: ${id}`;
  if (name) text += `\nname: ${name}`;
  text += `\ntype: ${isGroup ? 'group' : 'private'}`;
  await msg.reply(text);
}
