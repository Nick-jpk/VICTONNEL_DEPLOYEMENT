import type { Message } from '../services/whatsapp.js';

export async function handleWhoAmI(msg: Message) {
  const contact = await msg.getContact();
  const jid = (contact.id as any)?._serialized || (msg.author || msg.from);
  const name = (contact.pushname || contact.name || '').trim() || 'Unknown';
  const lines = [
    `Name: ${name}`,
    `JID: ${jid}`,
  ];
  await msg.reply(lines.join('\n'));
}
