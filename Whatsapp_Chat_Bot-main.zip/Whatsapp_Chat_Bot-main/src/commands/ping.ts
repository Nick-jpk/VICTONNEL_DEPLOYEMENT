import type { Message } from '../services/whatsapp.js';

export async function handlePing(msg: Message) {
  await msg.reply('pong');
}
