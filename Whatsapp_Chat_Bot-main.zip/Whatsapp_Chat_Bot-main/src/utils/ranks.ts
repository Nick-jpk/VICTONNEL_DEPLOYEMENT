export function rankName(elo: number): string {
  if (elo < 50) return 'Unranked';
  if (elo < 100) return 'Prepubescent rank';
  if (elo < 200) return 'Potato';
  if (elo < 300) return 'Wannabe Tryhard';
  if (elo < 400) return 'Big brain';
  if (elo < 500) return 'Gremlin';
  if (elo < 600) return 'Facts Gobbler';
  if (elo < 700) return 'Guru';
  if (elo < 800) return 'Final Boss';
  if (elo < 900) return 'Supreme Lorekeeper';
  return 'CEO of JJ';
}
