export function maybeGc(label?: string) {
  const g: any = globalThis as any;
  if (typeof g.gc === 'function') {
    try {
      g.gc();
    } catch {}
  }
}

