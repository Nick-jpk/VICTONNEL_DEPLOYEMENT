import { logger } from './utils/logger.js';
import { createClient, onMessage } from './services/whatsapp.js';
import { routeCommand } from './commands/router.js';
import { startHttpServer } from './services/http.js';
import { config } from './config/index.js';
import { connectMongo } from './db/mongo.js';
import { handleTriviaAnswer, isTriviaActive } from './modules/trivia/index.js';
import { handleCoinflipMessage, isCoinflipActive } from './modules/coinflip/index.js';
import { handleCasinoMessage, isAnyCasinoActive } from './modules/casino/manager.js';
import { isAnyGameActive, unlockGame } from './modules/gameLock.js';
import { maybeGc } from './utils/gc.js';
import { isAdmin } from './admin/auth.js';
import { cancelTrivia } from './modules/trivia/index.js';
import { cancelCoinflip } from './modules/coinflip/index.js';
import { resetCasino } from './modules/casino/manager.js';
import { cancelBeg } from './modules/beg/index.js';
import { refreshContentCache, sendLatestContentToChat } from './commands/content.js';

async function main() {
  startHttpServer(); // For Render Web Service health

  // Initialize DB (optional for current MVP, ensures readiness)
  await connectMongo().catch((err) => {
    logger.warn({ err }, 'MongoDB connection failed (continuing without DB)');
  });

  const client = await createClient();

  // Daily content cache refresh at 1:02 PM America/New_York (no posting)
  let lastContentRefreshDate = '';
  function getNYParts(d: Date) {
    const fmt = new Intl.DateTimeFormat('en-US', {
      timeZone: 'America/New_York', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hour12: false,
    });
    const parts = fmt.formatToParts(d).reduce((acc: any, p) => { acc[p.type] = p.value; return acc; }, {} as any);
    const year = parts.year;
    const month = parts.month;
    const day = parts.day;
    const hour = parseInt(parts.hour, 10);
    const minute = parseInt(parts.minute, 10);
    return { dateStr: `${year}-${month}-${day}`, hour, minute };
  }
  setInterval(async () => {
    try {
      const gid = config.allowedGroupId;
      if (!gid) return; // require explicit target chat (used to scope features)
      const { dateStr, hour, minute } = getNYParts(new Date());
      if (hour === 13 && minute === 2 && lastContentRefreshDate !== dateStr) {
        lastContentRefreshDate = dateStr;
        // Refresh cache with items from the last 4 minutes (12:58–13:02 ET)
        try {
          const n = await refreshContentCache(4);
          logger.info({ count: n }, 'content cache refreshed');
        } catch (e) {
          logger.warn({ e }, 'content cache refresh failed');
        }
        // Immediately post refreshed images to the group
        try {
          await sendLatestContentToChat(client, gid);
        } catch (e) {
          logger.warn({ e }, 'failed to auto-post refreshed content');
        }
      }
    } catch (e) {
      logger.warn({ e }, 'autopost scheduler tick failed');
    }
  }, 30 * 1000);

  // Deduplicate messages across multiple events using a short-lived cache
  const seen = new Set<string>();
  function markSeen(id: string) {
    if (seen.has(id)) return true;
    seen.add(id);
    setTimeout(() => seen.delete(id), 30_000);
    return false;
  }

  // Per‑chat mailbox to serialize ALL message handling (commands + game inputs)
  type Job = { execute: () => Promise<void>; createdAt: number };
  const queues = new Map<string, { running: boolean; items: Job[] }>();

  function enqueue(chatId: string, job: Job) {
    const q = queues.get(chatId) || { running: false, items: [] };
    q.items.push(job);
    queues.set(chatId, q);
    if (!q.running) void processQueue(chatId);
  }

  async function processQueue(chatId: string) {
    const q = queues.get(chatId);
    if (!q || q.running) return;
    q.running = true;
    try {
      while (q.items.length) {
        const job = q.items.shift()!;
        await Promise.race([
          job.execute().catch(() => {}),
          new Promise((r) => setTimeout(r, 10_000)),
        ]);
        await new Promise((r) => setTimeout(r, 100));
      }
    } finally {
      q.running = false;
      if (q.items.length === 0) queues.delete(chatId);
    }
  }

  onMessage(client, async (msg) => {
    try {
      if ((msg as any).fromMe) return;
      const mid = (msg as any)?.id?._serialized;
      if (mid && markSeen(mid)) return;
      const chat = await msg.getChat();
      const chatId = chat.id._serialized;
      if (config.allowedGroupId && chatId !== config.allowedGroupId) return;

      const body = (msg.body || '').trim();
      const isCommand = body.startsWith('!');

      // Admin utilities: immediate commands that bypass queue
      if (isCommand) {
        const [cmd] = body.slice(1).split(/\s+/);
        const cmdLower = cmd.toLowerCase();
        const senderId = ((msg as any).author || (msg as any).from) as string | undefined;
        if (cmdLower === 'clearqueue') {
          if (!isAdmin(senderId)) { await msg.reply('Admin only.'); return; }
          const q = queues.get(chatId);
          if (q) q.items = [];
          await msg.reply('Cleared pending commands for this chat.');
          return;
        }
        if (cmdLower === 'reset') {
          if (!isAdmin(senderId)) { await msg.reply('Admin only.'); return; }
          // Stop any running games and return bot to neutral state for this chat
          try { cancelBeg(chatId); } catch {}
          try { cancelTrivia(chatId); } catch {}
          try { cancelCoinflip(chatId); } catch {}
          try { resetCasino(chatId); } catch {}
          // Clear the command queue
          const q = queues.get(chatId); if (q) q.items = [];
          // Ensure unlocked
          try { unlockGame(chatId); } catch {}
          await msg.reply('Reset complete: cancelled active games and cleared queue.');
          return;
        }
      }

      // Enqueue ALL messages to ensure per‑chat serial processing
      enqueue(chatId, {
        createdAt: Date.now(),
        execute: async () => {
          if (isCommand) {
            await routeCommand(client, msg);
          } else {
            // Game inputs (answers/bets/joins)
            await handleTriviaAnswer(msg);
            await handleCoinflipMessage(msg);
            await handleCasinoMessage(msg);
          }
        },
      });
    } catch (err) {
      logger.error({ err }, 'Failed to handle message');
    }
  });

  // Optional periodic GC on tiny containers if enabled
  setInterval(() => maybeGc('interval'), 5 * 60 * 1000);
  // Baileys manages its own connection; no explicit initialize/keepalive needed
}

main().catch((err) => {
  logger.fatal({ err }, 'Fatal error starting bot');
  process.exit(1);
});
