const activeChats = new Set<string>();

export function lockGame(chatId: string) {
  activeChats.add(chatId);
}

export function unlockGame(chatId: string) {
  activeChats.delete(chatId);
}

export function isAnyGameActive(chatId: string): boolean {
  return activeChats.has(chatId);
}

