import { Message } from '../../services/whatsapp.js';
import { getDb } from '../../db/mongo.js';
import { logger } from '../../utils/logger.js';

interface BegSession {
  chatId: string;
  beggarId: string;
  beggarName: string;
  startedSec: number;
  timeout?: NodeJS.Timeout;
  givenCount: number;
}

const sessions = new Map<string, BegSession>();

export function isBegActive(chatId: string): boolean {
  return sessions.has(chatId);
}

export function cancelBeg(chatId: string) {
  const s = sessions.get(chatId);
  if (!s) return;
  if (s.timeout) clearTimeout(s.timeout);
  sessions.delete(chatId);
}

export async function startBeg(msg: Message) {
  const chat = await msg.getChat();
  const chatId = (chat as any).id?._serialized as string;
  if (sessions.has(chatId)) {
    await msg.reply('Someone is already begging.');
    return;
  }
  const beggarId = (msg.author || msg.from) as string;
  const beggarName = await displayName(msg);
  const startSec = (msg as any)?.timestamp || Math.floor(Date.now() / 1000);

  sessions.set(chatId, { chatId, beggarId, beggarName, startedSec: startSec, givenCount: 0 });
  await chat.sendMessage('This poor homeless guy is looking for $10 to continue gambling. Type !give to donate $10.');

  const nowSec = Math.floor(Date.now() / 1000);
  const delayMs = Math.max(0, (startSec + 30) - nowSec) * 1000;
  const timeout = setTimeout(async () => {
    try {
      const s = sessions.get(chatId);
      if (!s) return;
      if (s.givenCount === 0) {
        await chat.sendMessage('No one gave money');
      }
      sessions.delete(chatId);
    } catch (e) {
      logger.warn({ e }, 'beg timeout message failed');
    }
  }, delayMs);
  sessions.get(chatId)!.timeout = timeout;
}

export async function handleGive(msg: Message) {
  const chat = await msg.getChat();
  const chatId = (chat as any).id?._serialized as string;
  const s = sessions.get(chatId);
  if (!s) return; // no active beg

  const giverId = (msg.author || msg.from) as string;
  const giverName = await displayName(msg);
  if (giverId === s.beggarId) {
    await msg.reply('You cannot give to yourself.');
    return;
  }

  // Move $10 from giver to beggar if giver has funds
  try {
    const db = getDb();
    const now = new Date();
    // Check balance first
    const before = await db.collection('user_stats').findOne(
      { userId: giverId },
      { projection: { balance: 1 } }
    );
    const prevBal = typeof before?.balance === 'number' ? before.balance : 500;
    if (prevBal < 10) {
      await msg.reply('Insufficient funds.');
      return;
    }

    // Deduct $10 from giver
    await db.collection('user_stats').updateOne(
      { userId: giverId },
      [
        {
          $set: {
            balance: { $subtract: [{ $ifNull: ['$balance', 500] }, 10] },
            lastSeenName: giverName,
            updatedAt: now,
            createdAt: { $ifNull: ['$createdAt', now] },
          },
        },
      ],
      { upsert: true }
    );

    // Credit beggar +10
    await db.collection('user_stats').updateOne(
      { userId: s.beggarId },
      [
        {
          $set: {
            balance: { $add: [{ $ifNull: ['$balance', 500] }, 10] },
            lastSeenName: s.beggarName,
            updatedAt: now,
            createdAt: { $ifNull: ['$createdAt', now] },
          },
        },
      ],
      { upsert: true }
    );

    await chat.sendMessage(`${giverName} gave money to ${s.beggarName}`);
    // Keep beg session open for more gives until timeout
    s.givenCount += 1;
  } catch (e) {
    logger.warn({ e }, 'failed to process give');
  }
}

async function displayName(msg: Message): Promise<string> {
  try {
    const c = await msg.getContact();
    return (c.pushname || c.name || (c as any)?.id?._serialized || '').toString();
  } catch {
    return (msg.author || msg.from) as string;
  }
}
