import type { WASocket } from '@whiskeysockets/baileys';
import type { Message } from '../../services/whatsapp.js';
import { TAGS } from './data.js';

export async function mentionTag(client: WASocket, msg: Message, tagKey: keyof typeof TAGS) {
  const ids = TAGS[tagKey as string] || [];
  if (!ids.length) {
    await msg.reply(`No members configured for @${String(tagKey)} yet.`);
    return;
  }

  const chat = await msg.getChat();
  if (!chat.isGroup) {
    await msg.reply('This command only works in a group chat.');
    return;
  }

  const md = await client.groupMetadata(chat.id._serialized);
  const memberSet = new Set((md.participants || []).map((p: any) => p.id || p.id?._serialized));
  const targetIds = ids.filter((id) => memberSet.has(id));
  if (!targetIds.length) {
    await msg.reply('No configured members of this tag are in this group.');
    return;
  }

  const names = targetIds.map((id) => `@${id.split('@')[0]}`);
  const text = `${String(tagKey)}: ${names.join(' ')}`;
  await client.sendMessage(chat.id._serialized, { text, mentions: targetIds });
}
