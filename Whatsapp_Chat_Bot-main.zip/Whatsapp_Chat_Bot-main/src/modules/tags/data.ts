// Fill these arrays with WhatsApp JIDs (e.g., 1234567890@c.us or ...@lid)
// Names are for readability only; mentions use IDs.
export const TAGS: Record<string, string[]> = {
  fifagang: [
    '16077747343@c.us','923003361996@c.us','923378031577@c.us','923015106259@c.us','923038997893@c.us','923139222097@c.us','923010067422@c.us','923000110234@c.us','971558457656@c.us','923321049497@c.us'
  ],
  rankedsquad: [
    '447467890100@c.us', '971558457656@c.us','16077747343@c.us','923479700052@c.us','923139222097@c.us'
  ],
};

