export type TriviaOptionKey = 'A' | 'B' | 'C' | 'D';

export interface TriviaQuestion {
  id: string;
  question: string;
  options: Record<TriviaOptionKey, string>;
  answer: TriviaOptionKey; // correct option letter
  category?: string;
}

export interface TriviaSession {
  chatId: string;
  status: 'idle' | 'countdown' | 'asking' | 'finished';
  questionIndex: number;
  questions: TriviaQuestion[];
  perQuestionTimeoutMs: number;
  perQuestionTimer?: NodeJS.Timeout;
  // Guard to avoid double-finishing due to overlapping timers/events
  ended?: boolean;
  // Timing based on WhatsApp message timestamp (seconds)
  questionStartSec: number;
  // Track first answer per user for current question
  answeredBy: Map<string, { answer: TriviaOptionKey; t: number; rawBonus: number } >;
  // Aggregate scores across questions for this session
  scores: Map<string, number>;
  // Count correct answers per user (for n=1 rule)
  correctCounts: Map<string, number>;
  // Best-effort display names for users
  names: Map<string, string>;
  // For end-of-game reveal
  correctAnswers: TriviaOptionKey[];
  // For persistence
  startedAtMs: number;
}
