import { Message } from '../../services/whatsapp.js';
import { logger } from '../../utils/logger.js';
import type { TriviaOptionKey, TriviaQuestion, TriviaSession } from './types.js';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const questionsData = require('../../data/trivia/questions.json') as TriviaQuestion[];
import { performance } from 'node:perf_hooks';
import { getDb } from '../../db/mongo.js';

const MAX_QUESTIONS_PER_SESSION = 5;
// Scoring constants
const BASE = 0.80;
const SPEED_POOL = 0.20;
const BONUS_WINDOW_S = 20; // seconds (speed bonus lasts full question window)
const TIMEOUT_S = 20; // seconds
const TIE_WINDOW_MS = 100; // ms
const DISPLAY_PRECISION = 3;
const DEFAULT_PER_QUESTION_TIMEOUT_MS = TIMEOUT_S * 1000;
// We align timers to WhatsApp message timestamps now

// Active sessions per chat
const sessions = new Map<string, TriviaSession>();

export function isTriviaActive(chatId: string): boolean {
  const s = sessions.get(chatId);
  return !!s && (s.status === 'countdown' || s.status === 'asking');
}

export function cancelTrivia(chatId: string) {
  const s = sessions.get(chatId);
  if (!s) return;
  if (s.perQuestionTimer) clearTimeout(s.perQuestionTimer);
  sessions.delete(chatId);
}

function loadQuestions(): TriviaQuestion[] {
  // In MVP, read from bundled JSON
  const arr = questionsData as unknown as TriviaQuestion[];
  return arr;
}

function formatQuestion(q: TriviaQuestion, idx: number, total: number) {
  const lines = [
    `Question ${idx + 1}/${total}: ${q.question}`,
    `A) ${q.options.A}`,
    `B) ${q.options.B}`,
    `C) ${q.options.C}`,
    `D) ${q.options.D}`,
    '',
    'Reply with A, B, C, or D (single letter only).',
  ];
  return lines.join('\n');
}

async function askNextQuestion(msg: Message, session: TriviaSession) {
  const chat = await msg.getChat();

  if (session.questionIndex >= session.questions.length) {
    if (!session.ended) {
      session.ended = true;
      session.status = 'finished';
      await endGameAndAnnounce(chat.id._serialized as string, msg, session);
    }
    return;
  }

  session.status = 'asking';
  session.answeredBy.clear();
  const q = session.questions[session.questionIndex];
  // Shuffle the option order and adjust the correct answer mapping per display
  shuffleOptionsInPlace(q);
  const total = session.questions.length;
  const sent = await chat.sendMessage(formatQuestion(q, session.questionIndex, total));
  // Use WhatsApp timestamp (seconds) as the canonical start time
  const startSec = (sent as any)?.timestamp || Math.floor(Date.now() / 1000);
  session.questionStartSec = startSec;

  // Start timer for the question
  const nowSec = Math.floor(Date.now() / 1000);
  const delayMs = Math.max(0, (startSec + TIMEOUT_S) - nowSec) * 1000;
  session.perQuestionTimer = setTimeout(async () => {
    try {
      // At timeout: tally scores for this question using tie-window and speed pool
      if (!session.ended) {
        tallyQuestionScores(session, q);
        // Store for end-of-game reveal only
        session.correctAnswers.push(q.answer);
        session.questionIndex += 1;
        await askNextQuestion(msg, session);
      }
    } catch (err) {
      logger.error({ err }, 'Error in question timeout');
    }
  }, delayMs);
}

export async function startTrivia(msg: Message) {
  const chat = await msg.getChat();
  const chatId = (chat as any).id?._serialized as string;

  if (sessions.has(chatId)) {
    await msg.reply('Trivia is already running in this chat.');
    return;
  }
  // Cancel beg if active in this chat
  try {
    const { cancelBeg } = await import('../beg/index.js');
    cancelBeg(chatId);
  } catch {}

  const all = loadQuestions();
  if (!all.length) {
    await msg.reply('No trivia questions available.');
    return;
  }

  const count = Math.min(MAX_QUESTIONS_PER_SESSION, all.length);
  // Pick a random subset of questions and ask them in random order
  const indices = new Set<number>();
  while (indices.size < count) {
    indices.add(Math.floor(Math.random() * all.length));
  }
  const selected = Array.from(indices).map((i) => all[i]);
  // Fisher–Yates shuffle for random order
  for (let i = selected.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [selected[i], selected[j]] = [selected[j], selected[i]];
  }

  const session: TriviaSession = {
    chatId,
    status: 'countdown',
    questionIndex: 0,
    questions: selected,
    perQuestionTimeoutMs: DEFAULT_PER_QUESTION_TIMEOUT_MS,
    questionStartSec: 0,
    answeredBy: new Map(),
    scores: new Map(),
    correctCounts: new Map(),
    names: new Map(),
    correctAnswers: [],
    startedAtMs: Date.now(),
  };
  sessions.set(chatId, session);

  await chat.sendMessage('Trivia beginning in 5 seconds...');
  setTimeout(async () => {
    try {
      await askNextQuestion(msg, session);
    } catch (err) {
      logger.error({ err }, 'Failed to start first question');
    }
  }, 5000);
}

// Only accept a single-letter A/B/C/D, case-insensitive, and only first answer per user per question
export async function handleTriviaAnswer(msg: Message) {
  const chat = await msg.getChat();
  const chatId = (chat as any).id?._serialized as string;
  const session = sessions.get(chatId);
  if (!session || session.status !== 'asking') return; // no active question

  const body = (msg.body || '').trim();
  if (!/^[a-d]$/i.test(body)) return; // must be exactly one letter

  const userId = (msg.author || msg.from) as string;
  if (session.answeredBy.has(userId)) return; // first message only per user

  const answer = body.toUpperCase() as TriviaOptionKey;

  // Compute timing for speed scoring using WhatsApp timestamps (seconds)
  const msgSec = (msg as any)?.timestamp || Math.floor(Date.now() / 1000);
  let t = msgSec - session.questionStartSec;
  if (t < 0) t = 0;
  if (t > TIMEOUT_S) return; // ignore late answers beyond window

  let rawBonus = 0;
  // Linear speed bonus across the entire question window (0..20s)
  if (t <= TIMEOUT_S) {
    rawBonus = SPEED_POOL * (1 - t / TIMEOUT_S);
  } else {
    rawBonus = 0;
  }
  // Clamp bonus
  rawBonus = Math.max(0, Math.min(SPEED_POOL, rawBonus));

  session.answeredBy.set(userId, { answer, t, rawBonus });

  // Cache display name for final scoreboard and persistence
  try {
    const contact = await msg.getContact();
    const name = contact?.pushname || contact?.name || userId;
    session.names.set(userId, name);
  } catch {
    // ignore
  }
}

function tallyQuestionScores(session: TriviaSession, q: TriviaQuestion) {
  // Collect correct answers with timing
  const correct: { userId: string; t: number; rawBonus: number }[] = [];
  for (const [userId, data] of session.answeredBy.entries()) {
    if (data.answer === q.answer) {
      correct.push({ userId, t: data.t, rawBonus: data.rawBonus });
    }
  }
  if (correct.length === 0) return;
  correct.sort((a, b) => a.t - b.t);

  // Group by tie window (100 ms)
  const groups: { startT: number; members: typeof correct }[] = [] as any;
  let current: { startT: number; members: typeof correct } | null = null;
  for (const item of correct) {
    if (!current) {
      current = { startT: item.t, members: [item] as any };
      groups.push(current);
      continue;
    }
    if (item.t - current.startT <= TIE_WINDOW_MS / 1000) {
      current.members.push(item);
    } else {
      current = { startT: item.t, members: [item] as any };
      groups.push(current);
    }
  }

  // Assign group bonus as first.rawBonus for each group member
  for (const g of groups) {
    const groupBonus = g.members[0].rawBonus;
    for (const m of g.members) {
      const finalScore = Math.max(0, Math.min(1, BASE + groupBonus));
      session.scores.set(m.userId, (session.scores.get(m.userId) || 0) + finalScore);
      // Track correct count for n=1 rule
      session.correctCounts.set(m.userId, (session.correctCounts.get(m.userId) || 0) + 1);
    }
  }
}

function shuffleOptionsInPlace(q: TriviaQuestion) {
  const entries: Array<[TriviaOptionKey, string]> = [
    ['A', q.options.A],
    ['B', q.options.B],
    ['C', q.options.C],
    ['D', q.options.D],
  ];
  // Fisher–Yates shuffle
  for (let i = entries.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [entries[i], entries[j]] = [entries[j], entries[i]];
  }
  const letters: TriviaOptionKey[] = ['A', 'B', 'C', 'D'];
  const newOptions: Record<TriviaOptionKey, string> = { A: '', B: '', C: '', D: '' };
  let newAnswer: TriviaOptionKey = 'A';
  for (let i = 0; i < entries.length; i++) {
    const [origKey, text] = entries[i];
    const dispKey = letters[i];
    newOptions[dispKey] = text;
    if (origKey === q.answer) newAnswer = dispKey;
  }
  q.options = newOptions;
  q.answer = newAnswer;
}

async function endGameAndAnnounce(chatId: string, msg: Message, session: TriviaSession) {
  const chat = await msg.getChat();
  // Build final scoreboard
  const entries = Array.from(session.scores.entries());
  entries.sort((a, b) => b[1] - a[1]);
  // Prepare participants and standings (include zero-score players)
  const participantsSet = new Set<string>();
  for (const userId of session.names.keys()) participantsSet.add(userId);
  for (const userId of session.scores.keys()) participantsSet.add(userId);
  const participants = Array.from(participantsSet);
  const sortedStandings = participants
    .map((userId) => ({ userId, score: session.scores.get(userId) || 0 }))
    .sort((a, b) => b.score - a.score);
  const maxScore = Math.max(0, ...sortedStandings.map((s) => s.score));
  const winners = sortedStandings.filter((s) => s.score === maxScore).map((s) => s.userId);

  // Compute Elo deltas for display (best-effort)
  let eloMap = new Map<string, number>();
  try {
    const db = getDb();
    const existing = await db
      .collection('user_stats')
      .find({ userId: { $in: participants } }, { projection: { userId: 1, elo: 1 } })
      .toArray();
    eloMap = new Map(existing.map((d: any) => [d.userId, typeof d.elo === 'number' ? d.elo : 0]));
  } catch {
    // If DB not available, assume elo=0 for display
  }

  // Build position map (competition ranking)
  const posMap = new Map<string, number>();
  let pos = 1;
  for (let i = 0; i < sortedStandings.length; ) {
    const score = sortedStandings[i].score;
    const tied: number[] = [];
    let j = i;
    while (j < sortedStandings.length && sortedStandings[j].score === score) {
      tied.push(j);
      j++;
    }
    for (const idx of tied) posMap.set(sortedStandings[idx].userId, pos);
    pos += tied.length;
    i = j;
  }

  const n = participants.length;
  // Two-player draw rule: if tie and both have >=4 correct, both +20; else 0
  let twoPlayerDrawDelta: number | null = null;
  if (n === 2 && winners.length === 2) {
    const bothHaveFour = winners.every((u) => (session.correctCounts.get(u) || 0) >= 4);
    twoPlayerDrawDelta = bothHaveFour ? 20 : 0;
  }
  function deltaFor(userId: string): number {
    if (n === 1) {
      const correct = session.correctCounts.get(userId) || 0;
      return correct >= 4 ? 20 : -20;
    }
    const p = posMap.get(userId) || n;
    if (n === 2) {
      if (winners.length === 2 && twoPlayerDrawDelta !== null) return twoPlayerDrawDelta;
      return p === 1 ? 20 : -20;
    }
    if (n === 3) return p === 1 ? 20 : p === 2 ? 0 : -20;
    if (n === 4) return p === 1 ? 20 : p === 2 ? 10 : p === 3 ? -10 : -20;
    if (p === 1) return 20;
    if (p === 2) return 10;
    if (p === 3) return 0;
    if (p === 4) return -10;
    if (p === 5) return -20;
    return -20;
  }

  const lines: string[] = [];
  lines.push('Trivia complete! Final scores:');
  if (entries.length === 0) {
    lines.push('No correct answers recorded.');
  } else {
    let rank = 1;
    for (const { userId, score } of sortedStandings) {
      const name = session.names.get(userId) || userId;
      const oldElo = eloMap.get(userId) ?? 0;
      const dRaw = deltaFor(userId);
      const dAdj = Math.max(-oldElo, dRaw); // do not go below 0 elo
      const sign = dAdj > 0 ? `+${dAdj}` : `${dAdj}`;
      lines.push(`${rank}) ${name}: ${score.toFixed(DISPLAY_PRECISION)} (${sign})`);
      rank += 1;
    }
  }
  // Correct answers reveal
  if (session.correctAnswers.length > 0) {
    lines.push('');
    lines.push(`Correct Answers: ${session.correctAnswers.join(' ')}`);
  }
  await chat.sendMessage(lines.join('\n'));

  // Persist minimal user stats to MongoDB (best-effort)
  try {
    const db = getDb();
    // Compute ELO deltas by finishing position and update user_stats only
    // Build position map with competition ranking (1,1,3)
    const posMap = new Map<string, number>();
    let pos = 1;
    for (let i = 0; i < sortedStandings.length; ) {
      const score = sortedStandings[i].score;
      const tied: number[] = [];
      let j = i;
      while (j < sortedStandings.length && sortedStandings[j].score === score) {
        tied.push(j);
        j++;
      }
      for (const idx of tied) posMap.set(sortedStandings[idx].userId, pos);
      pos += tied.length;
      i = j;
    }

    const n = participants.length;
    // Two-player draw rule inside DB update as well
    let twoPlayerDrawDelta: number | null = null;
    if (n === 2 && winners.length === 2) {
      const bothHaveFour = winners.every((u) => (session.correctCounts.get(u) || 0) >= 4);
      twoPlayerDrawDelta = bothHaveFour ? 20 : 0;
    }
    // Helper to get delta based on position and player count
    function deltaFor(userId: string): number {
      if (n === 1) {
        const correct = session.correctCounts.get(userId) || 0;
        return correct >= 4 ? 20 : -20;
      }
      const p = posMap.get(userId) || n; // default to last
      if (n === 2) {
        if (winners.length === 2 && twoPlayerDrawDelta !== null) return twoPlayerDrawDelta;
        return p === 1 ? 20 : -20;
      }
      if (n === 3) return p === 1 ? 20 : p === 2 ? 0 : -20;
      if (n === 4) return p === 1 ? 20 : p === 2 ? 10 : p === 3 ? -10 : -20;
      // n >= 5
      if (p === 1) return 20;
      if (p === 2) return 10;
      if (p === 3) return 0;
      if (p === 4) return -10;
      if (p === 5) return -20;
      return -20;
    }

    // Fetch existing stats to clamp elo at 0 and compute new values
    const bulk = db.collection('user_stats').initializeUnorderedBulkOp();
    for (const userId of participants) {
      const isWinner = winners.includes(userId);
      const oldElo = eloMap.get(userId) || 0;
      const d = Math.max(-oldElo, deltaFor(userId));
      const newElo = Math.max(0, oldElo + d);
      bulk.find({ userId }).upsert().updateOne({
        $set: {
          elo: newElo,
          lastSeenName: session.names.get(userId) || userId,
          updatedAt: new Date(),
        },
        $setOnInsert: { createdAt: new Date() },
        $inc: { gamesPlayed: 1, wins: isWinner ? 1 : 0 },
      });
    }
    if (participants.length > 0) await bulk.execute();
  } catch (err) {
    // DB may not be configured; ignore errors
    logger.warn({ err }, 'Failed to persist trivia game summary');
  }

  sessions.delete(session.chatId);
  // Hint GC on tiny containers if enabled
  try {
    const { maybeGc } = await import('../../utils/gc.js');
    maybeGc('after-trivia');
  } catch {}
}
