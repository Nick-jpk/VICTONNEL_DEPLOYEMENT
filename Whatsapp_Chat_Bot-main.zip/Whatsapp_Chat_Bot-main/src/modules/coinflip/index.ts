import { Message } from '../../services/whatsapp.js';
import { performance } from 'node:perf_hooks';
import { getDb } from '../../db/mongo.js';
import { logger } from '../../utils/logger.js';

type Side = 'heads' | 'tails';

interface Bet {
  userId: string;
  name: string;
  amount: number;
  side: Side;
}

interface CoinflipSession {
  chatId: string;
  status: 'idle' | 'countdown' | 'locked' | 'finished';
  startEpochSec: number; // WhatsApp message timestamp (seconds)
  lockEpochSec: number;
  endEpochSec: number;
  timers: NodeJS.Timeout[];
  bets: Map<string, Bet>; // first valid bet only
  failedBroke: Map<string, string>; // userId -> name (only balance==0 attempts)
}

const sessions = new Map<string, CoinflipSession>();

export function isCoinflipActive(chatId: string): boolean {
  const s = sessions.get(chatId);
  return !!s && (s.status === 'countdown' || s.status === 'locked');
}

export function cancelCoinflip(chatId: string) {
  const s = sessions.get(chatId);
  if (!s) return;
  clearTimers(s);
  sessions.delete(chatId);
}

function clearTimers(s: CoinflipSession) {
  for (const t of s.timers) clearTimeout(t);
  s.timers = [];
}

export async function startCoinflip(msg: Message) {
  const chat = await msg.getChat();
  const chatId = (chat as any).id?._serialized as string;
  if (sessions.has(chatId)) {
    await msg.reply('A coinflip is already in progress.');
    return;
  }

  const s: CoinflipSession = {
    chatId,
    status: 'countdown',
    startEpochSec: 0,
    lockEpochSec: 0,
    endEpochSec: 0,
    timers: [],
    bets: new Map(),
    failedBroke: new Map(),
  };
  sessions.set(chatId, s);

  const sent = await chat.sendMessage(
    'Coinflip in 1 minute — get your bets in!\n' +
      'Format: bet 10 heads or bet 10 tails. Min bet $10.'
  );

  const startSec = (sent as any)?.timestamp || Math.floor(Date.now() / 1000);
  s.startEpochSec = startSec;
  s.lockEpochSec = startSec + 55;
  s.endEpochSec = startSec + 60;

  // 30s reminder
  const nowSec = Math.floor(Date.now() / 1000);
  const in30Ms = Math.max(0, (startSec + 30) - nowSec) * 1000;
  s.timers.push(
    setTimeout(async () => {
      try {
        const c = await msg.getChat();
        await c.sendMessage(
          'Coinflip in 30 seconds — last chance to bet!\n' +
            'Format: bet 10 heads or bet 10 tails.'
        );
      } catch (e) {
        logger.warn({ e }, 'coinflip 30s reminder failed');
      }
    }, in30Ms)
  );

  // 5s lock
  const in55Ms = Math.max(0, (startSec + 55) - nowSec) * 1000;
  s.timers.push(
    setTimeout(async () => {
      try {
        s.status = 'locked';
        const c = await msg.getChat();
        await c.sendMessage('Bets locked. Coinflip in 5 seconds.');
      } catch (e) {
        logger.warn({ e }, 'coinflip lock message failed');
      }
    }, in55Ms)
  );

  // Resolve at 60s
  const in60Ms = Math.max(0, (startSec + 60) - nowSec) * 1000;
  s.timers.push(
    setTimeout(async () => {
      await resolveCoinflip(msg, s).catch((e) => logger.error({ e }, 'resolve coinflip failed'));
    }, in60Ms)
  );
}

export async function handleCoinflipMessage(msg: Message) {
  const chat = await msg.getChat();
  const chatId = (chat as any).id?._serialized as string;
  const s = sessions.get(chatId);
  if (!s || (s.status !== 'countdown' && s.status !== 'locked')) return;

  const body = (msg.body || '').trim();
  const m = body.match(/^bet\s+(\d+)\s+(heads|tails)\s*$/i);
  if (!m) return; // only accept strict format

  const amount = parseInt(m[1], 10);
  const side = m[2].toLowerCase() as Side;
  const userId = (msg.author || msg.from) as string;

  const msgSec = (msg as any)?.timestamp || Math.floor(Date.now() / 1000);
  if (s.status === 'locked' || msgSec >= s.lockEpochSec) {
    // Bets locked; ignore
    return;
  }
  if (s.bets.has(userId)) {
    // First valid bet only
    return;
  }
  if (amount < 10) {
    await msg.reply('Minimum bet is $10.');
    return;
  }

  // Check balance
  const name = await getDisplayName(msg);
  try {
    const db = getDb();
    const doc = await db.collection('user_stats').findOne(
      { userId },
      { projection: { balance: 1 } }
    );
    const balance = typeof doc?.balance === 'number' ? doc!.balance : 500;
    if (balance <= 0) {
      s.failedBroke.set(userId, name);
      await msg.reply('Insufficient funds.');
      return;
    }
    if (amount > balance) {
      await msg.reply(`Bet exceeds your balance ($${balance}).`);
      return;
    }
    // Accept bet
    s.bets.set(userId, { userId, name, amount, side });
    await msg.reply('👍');
  } catch (e) {
    logger.warn({ e }, 'balance lookup failed');
  }
}

async function resolveCoinflip(msg: Message, s: CoinflipSession) {
  s.status = 'finished';
  clearTimers(s);
  const chat = await msg.getChat();
  const chatId = s.chatId;

  // Flip coin
  const flip: Side = Math.random() < 0.5 ? 'heads' : 'tails';

  // Split winners/losers
  const winners: Bet[] = [];
  const losers: Bet[] = [];
  for (const bet of s.bets.values()) {
    if (bet.side === flip) winners.push(bet); else losers.push(bet);
  }

  // Persist balances atomically using pipeline updates (default balance 500)
  try {
    const db = getDb();
    const now = new Date();
    const ops: any[] = [];
    for (const w of winners) {
      ops.push({
        updateOne: {
          filter: { userId: w.userId },
          update: [
            {
              $set: {
                balance: { $add: [{ $ifNull: ['$balance', 500] }, w.amount] },
                lastSeenName: w.name,
                updatedAt: now,
                createdAt: { $ifNull: ['$createdAt', now] },
              },
            },
          ],
          upsert: true,
        },
      });
    }
    for (const l of losers) {
      ops.push({
        updateOne: {
          filter: { userId: l.userId },
          update: [
            {
              $set: {
                balance: { $add: [{ $ifNull: ['$balance', 500] }, -l.amount] },
                lastSeenName: l.name,
                updatedAt: now,
                createdAt: { $ifNull: ['$createdAt', now] },
              },
            },
          ],
          upsert: true,
        },
      });
    }
    if (ops.length) await db.collection('user_stats').bulkWrite(ops, { ordered: false });
  } catch (e) {
    logger.warn({ e }, 'failed to persist coinflip balances');
  }

  // Build summary
  const lines: string[] = [];
  lines.push(`Result: ${flip.toUpperCase()}`);
  if (winners.length) {
    lines.push('');
    lines.push('Winners:');
    for (const w of winners) {
      lines.push(`${w.name} won $${w.amount}`);
    }
  }
  if (losers.length) {
    lines.push('');
    lines.push('Losers:');
    for (const l of losers) {
      lines.push(`${l.name} lost $${l.amount}`);
    }
  }
  if (s.failedBroke.size) {
    lines.push('');
    lines.push('Failed bets:');
    for (const name of s.failedBroke.values()) {
      lines.push(`${name}, Get your money up before betting broke boy`);
    }
  }

  // Append current balances for participants
  try {
    const db = getDb();
    const ids = Array.from(new Set([...s.bets.keys()]));
    if (ids.length) {
      const docs = await db
        .collection('user_stats')
        .find({ userId: { $in: ids } }, { projection: { userId: 1, balance: 1 } })
        .toArray();
      const map = new Map(docs.map((d: any) => [d.userId, typeof d.balance === 'number' ? d.balance : 500]));
      lines.push('');
      lines.push('Balances:');
      for (const bet of s.bets.values()) {
        const bal = map.get(bet.userId);
        if (typeof bal === 'number') lines.push(`${bet.name}: $${bal}`);
      }
    }
  } catch {}

  await chat.sendMessage(lines.join('\n'));
  sessions.delete(chatId);
}

async function getDisplayName(msg: Message): Promise<string> {
  try {
    const c = await msg.getContact();
    return (c?.pushname || c?.name || (c as any)?.id?._serialized || '').toString();
  } catch {
    return (msg.author || msg.from) as string;
  }
}
