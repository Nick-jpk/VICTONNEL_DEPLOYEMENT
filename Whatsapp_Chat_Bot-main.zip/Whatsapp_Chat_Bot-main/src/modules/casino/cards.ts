export type Card = { rank: string; suit: string; value: number };

const RANKS: { rank: string; value: number }[] = [
  { rank: 'A', value: 11 },
  { rank: 'K', value: 10 },
  { rank: 'Q', value: 10 },
  { rank: 'J', value: 10 },
  { rank: '10', value: 10 },
  { rank: '9', value: 9 },
  { rank: '8', value: 8 },
  { rank: '7', value: 7 },
  { rank: '6', value: 6 },
  { rank: '5', value: 5 },
  { rank: '4', value: 4 },
  { rank: '3', value: 3 },
  { rank: '2', value: 2 },
];
const SUITS = ['♠', '♥', '♦', '♣'];

export function createDeck(count = 1): Card[] {
  const deck: Card[] = [];
  for (let c = 0; c < count; c++) {
    for (const s of SUITS) {
      for (const r of RANKS) {
        deck.push({ rank: r.rank, suit: s, value: r.value });
      }
    }
  }
  // shuffle
  for (let i = deck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [deck[i], deck[j]] = [deck[j], deck[i]];
  }
  return deck;
}

export function handValue(cards: Card[]): number {
  let total = 0;
  let aces = 0;
  for (const c of cards) {
    total += c.value;
    if (c.rank === 'A') aces++;
  }
  while (total > 21 && aces > 0) {
    total -= 10;
    aces--;
  }
  return total;
}

export function formatHand(cards: Card[]): string {
  return cards.map((c) => `${c.rank}${c.suit}`).join(' ');
}

