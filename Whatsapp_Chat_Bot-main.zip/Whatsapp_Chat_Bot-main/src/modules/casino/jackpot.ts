import type { Message } from '../../services/whatsapp.js';
import { getDb } from '../../db/mongo.js';
import { lockGame, unlockGame } from '../gameLock.js';

type Entry = { userId: string; name: string; amount: number };
const sessions = new Map<string, { entries: Entry[]; timer?: NodeJS.Timeout }>();
export function isJackpotActive(chatId: string){ return sessions.has(chatId); }

export function cancelJackpot(chatId: string){
  const s = sessions.get(chatId);
  if (!s) return;
  if (s.timer) clearTimeout(s.timer);
  sessions.delete(chatId);
  unlockGame(chatId);
}

export async function startJackpot(msg: Message){
  const chat = await msg.getChat(); const chatId = chat.id._serialized; if (sessions.has(chatId)) { await msg.reply('Jackpot already running.'); return; }
  lockGame(chatId);
  sessions.set(chatId, { entries: [] });
  await chat.sendMessage('💰 Jackpot started. 60s to join. Type: join 50 (default $50).');
  sessions.get(chatId)!.timer = setTimeout(()=>resolveJackpot(msg).catch(()=>{}), 60_000);
}

export async function handleJackpotMessage(msg: Message){
  const chat = await msg.getChat(); const chatId = chat.id._serialized; const s = sessions.get(chatId); if (!s) return;
  const body = (msg.body||'').trim();
  const m = body.match(/^join\s*(\d+)?$/i); if (!m) return;
  const amount = m[1]? Math.max(10, parseInt(m[1],10)) : 50;
  const userId = (msg.author||msg.from) as string; const name = (await msg.getContact()).pushname||userId;
  if (s.entries.find(e=>e.userId===userId)) { await msg.reply('You already joined.'); return; }
  const db = getDb(); const now = new Date(); const pre = await db.collection('user_stats').findOne({ userId },{ projection:{ balance:1 }});
  const balance = typeof pre?.balance==='number'? pre!.balance: 500; if (balance<amount){ await msg.reply(`Insufficient funds ($${balance})`); return; }
  await db.collection('user_stats').updateOne({ userId },[{ $set:{ balance:{ $subtract:[{ $ifNull:['$balance',500]}, amount]}, lastSeenName:name, updatedAt:now, createdAt:{ $ifNull:['$createdAt',now] } }}],{ upsert:true });
  s.entries.push({ userId, name, amount });
  await msg.reply(`${name} joined with $${amount}`);
}

async function resolveJackpot(msg: Message){
  const chat = await msg.getChat(); const chatId = chat.id._serialized; const s = sessions.get(chatId); if (!s){ return; }
  const total = s.entries.reduce((a,e)=>a+e.amount,0); if (total<=0){ await chat.sendMessage('No one joined.'); sessions.delete(chatId); unlockGame(chatId); return; }
  const fee = Math.floor(total*0.05); const pot = total - fee;
  const winner = s.entries[Math.floor(Math.random()*s.entries.length)];
  const db = getDb(); const now = new Date();
  await db.collection('user_stats').updateOne({ userId: winner.userId },[{ $set:{ balance:{ $add:[{ $ifNull:['$balance',500]}, pot]}, lastSeenName:winner.name, updatedAt:now, createdAt:{ $ifNull:['$createdAt',now] } }}],{ upsert:true });
  await chat.sendMessage(`💰 Jackpot winner: ${winner.name} +$${pot} (total pool $${total}, fee $${fee})`);
  if (s.timer) clearTimeout(s.timer); sessions.delete(chatId); unlockGame(chatId);
}
