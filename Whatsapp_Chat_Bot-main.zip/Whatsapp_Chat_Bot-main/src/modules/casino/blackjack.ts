import type { Message } from '../../services/whatsapp.js';
import { createDeck, handValue, formatHand, Card } from './cards.js';
import { getDb } from '../../db/mongo.js';
import { lockGame, unlockGame } from '../gameLock.js';

type Player = { userId: string; name: string; bet: number; hand: Card[]; done: boolean; busted: boolean };
const sessions = new Map<string, { players: Player[]; deck: Card[]; dealer: Card[]; phase: 'join'|'play'|'settle'; timer?: NodeJS.Timeout; ended?: boolean }>();

export function isBlackjackActive(chatId: string){ return sessions.has(chatId); }

export function cancelBlackjack(chatId: string){
  const s = sessions.get(chatId);
  if (!s) return;
  if (s.timer) clearTimeout(s.timer);
  sessions.delete(chatId);
  unlockGame(chatId);
}

export async function startBlackjack(msg: Message){
  const chat = await msg.getChat(); const chatId = chat.id._serialized; if (sessions.has(chatId)) { await msg.reply('Blackjack already running.'); return; }
  lockGame(chatId);
  sessions.set(chatId, { players: [], deck: createDeck(4), dealer: [], phase:'join' });
  await chat.sendMessage('🃏 Blackjack starting. 30s to join. Type: join 10 (min $10, default $10). One round only.');
  sessions.get(chatId)!.timer = setTimeout(()=> beginRound(msg).catch(()=>{}), 30_000);
}

export async function handleBlackjackMessage(msg: Message){
  const chat = await msg.getChat(); const chatId = chat.id._serialized; const s = sessions.get(chatId); if (!s) return;
  const body = (msg.body||'').trim().toLowerCase();
  const userId = (msg.author||msg.from) as string; const name = (await msg.getContact()).pushname||userId;
  const db = getDb(); const now = new Date();
  if (s.phase==='join'){
    const m = body.match(/^join\s*(\d+)?$/i); if (!m) return;
    const bet = m[1]? Math.max(10, parseInt(m[1],10)) : 10;
    if (s.players.find(p=>p.userId===userId)) { await msg.reply('Already joined.'); return; }
    const pre = await db.collection('user_stats').findOne({ userId },{ projection:{ balance:1 }});
    const balance = typeof pre?.balance==='number'? pre!.balance: 500; if (balance<bet){ await msg.reply(`Insufficient funds ($${balance})`); return; }
    await db.collection('user_stats').updateOne({ userId },[{ $set:{ balance:{ $subtract:[{ $ifNull:['$balance',500]}, bet]}, lastSeenName:name, updatedAt:now, createdAt:{ $ifNull:['$createdAt',now] } }}],{ upsert:true });
    s.players.push({ userId, name, bet, hand:[], done:false, busted:false });
    await msg.reply(`${name} joined with $${bet}`);
  } else if (s.phase==='play'){
    const p = s.players.find(p=>p.userId===userId); if (!p || p.done) return;
    if (body==='hit'){
      p.hand.push(s.deck.shift()!);
      const v = handValue(p.hand); if (v>21){ p.busted=true; p.done=true; await msg.reply(`${p.name} hits: ${formatHand(p.hand)} (bust)`);} else { await msg.reply(`${p.name} hits: ${formatHand(p.hand)} (${v})`);} 
    } else if (body==='stand'){
      p.done=true; await msg.reply(`${p.name} stands: ${formatHand(p.hand)} (${handValue(p.hand)})`);
    }
    // If all done, settle
    if (s.players.every(pl=>pl.done)) await settle(msg).catch(()=>{});
  }
}

async function beginRound(msg: Message){
  const chat = await msg.getChat(); const chatId = chat.id._serialized; const s = sessions.get(chatId); if (!s){ return; }
  if (s.players.length===0){ await chat.sendMessage('No players.'); cleanup(chatId); return; }
  s.phase = 'play'; s.dealer = []; s.deck = s.deck.length<30? createDeck(4): s.deck;
  // Deal initial
  for (const p of s.players){ p.hand=[s.deck.shift()!, s.deck.shift()!]; p.done=false; p.busted=false; }
  s.dealer.push(s.deck.shift()!, s.deck.shift()!);
  await chat.sendMessage(`Dealer: ${s.dealer[0].rank}${s.dealer[0].suit} [hidden]\n` + s.players.map(p=>`${p.name}: ${formatHand(p.hand)} (${handValue(p.hand)})`).join('\n') + '\nType hit or stand.');
  // 15 min failsafe
  if (s.timer) clearTimeout(s.timer); s.timer = setTimeout(()=>{ chat.sendMessage('Blackjack timed out. Ending.'); cleanup(chatId); }, 15*60*1000);
}

async function settle(msg: Message){
  const chat = await msg.getChat(); const chatId = chat.id._serialized; const s = sessions.get(chatId)!; if (s.ended) return; s.phase='settle'; s.ended = true;
  // Dealer draws to 17
  let dv = handValue(s.dealer);
  while (dv<17){ s.dealer.push(s.deck.shift()!); dv = handValue(s.dealer); }
  const db = getDb(); const now = new Date();
  const lines: string[] = [];
  lines.push(`Dealer: ${formatHand(s.dealer)} (${dv})`);
  for (const p of s.players){
    const pv = handValue(p.hand);
    let outcome = 'lose';
    if (p.busted) outcome='lose';
    else if (dv>21 || pv>dv) outcome='win';
    else if (pv===dv) outcome='push';
    if (outcome==='win'){
      const win = p.bet*2;
      await db.collection('user_stats').updateOne({ userId:p.userId },[{ $set:{ balance:{ $add:[{ $ifNull:['$balance',500]}, win] }, updatedAt:now }}],{ upsert:true });
      lines.push(`${p.name} wins $${p.bet}`);
    } else if (outcome==='push'){
      // refund bet
      await db.collection('user_stats').updateOne({ userId:p.userId },[{ $set:{ balance:{ $add:[{ $ifNull:['$balance',500]}, p.bet] }, updatedAt:now }}],{ upsert:true });
      lines.push(`${p.name} pushes (refund $${p.bet})`);
    } else {
      lines.push(`${p.name} loses $${p.bet}`);
    }
  }
  await chat.sendMessage(lines.join('\n'));
  cleanup(chatId);
}

function cleanup(chatId: string){
  const s = sessions.get(chatId); if (s?.timer) clearTimeout(s.timer); sessions.delete(chatId); unlockGame(chatId);
}
