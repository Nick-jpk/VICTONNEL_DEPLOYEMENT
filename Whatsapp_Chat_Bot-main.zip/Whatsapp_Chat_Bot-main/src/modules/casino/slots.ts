import { getDb } from '../../db/mongo.js';
import { lockGame, unlockGame, isAnyGameActive } from '../gameLock.js';
import type { Message } from '../../services/whatsapp.js';

const REELS = ['🍒', '🍋', '⭐', '🍀', '🔔', '7️⃣'];
const DEFAULT_BET = 25;

function spinReels(count = 3): string[] {
  const out: string[] = [];
  for (let i = 0; i < count; i++) out.push(REELS[Math.floor(Math.random() * REELS.length)]);
  return out;
}

function payout(symbols: string[], bet: number): number {
  const [a, b, c] = symbols;
  if (a === b && b === c) {
    // 3 of a kind: 5x
    return bet * 5;
  }
  if (a === b || b === c || a === c) {
    // 2 of a kind: 3x
    return bet * 3;
  }
  return 0;
}

export async function playSlots(msg: Message, betInput?: number) {
  const chat = await msg.getChat();
  const chatId = chat.id._serialized;
  if (isAnyGameActive(chatId)) {
    await msg.reply('A game is already running. Please wait.');
    return;
  }
  lockGame(chatId);
  try {
    const bet = Number.isFinite(betInput) && betInput! > 0 ? Math.floor(betInput!) : DEFAULT_BET;
    const userId = (msg.author || msg.from) as string;
    const name = (await msg.getContact()).pushname || userId;
    const db = getDb();
    const now = new Date();

    // Check balance
    const pre = await db.collection('user_stats').findOne({ userId }, { projection: { balance: 1 } });
    const balance = typeof pre?.balance === 'number' ? pre!.balance : 500;
    if (balance < bet) {
      await msg.reply(`Insufficient funds. Balance: $${balance}, bet: $${bet}`);
      return;
    }

    // Deduct bet
    await db.collection('user_stats').updateOne(
      { userId },
      [
        { $set: { balance: { $subtract: [{ $ifNull: ['$balance', 500] }, bet] }, lastSeenName: name, updatedAt: now, createdAt: { $ifNull: ['$createdAt', now] } } },
      ],
      { upsert: true }
    );

    // Spin
    const symbols = spinReels(3);

    // Reveal slowly with 5s delay between each reel
    await chat.sendMessage('🎰 Spinning...');
    const frame1 = `${symbols[0]} | ❔ | ❔`;
    const frame2 = `${symbols[0]} | ${symbols[1]} | ❔`;
    const frame3 = `${symbols[0]} | ${symbols[1]} | ${symbols[2]}`;
    await chat.sendMessage(frame1);
    await delay(5000);
    await chat.sendMessage(frame2);
    await delay(5000);
    await chat.sendMessage(frame3);

    const win = payout(symbols, bet);
    if (win > 0) {
      await db.collection('user_stats').updateOne(
        { userId },
        [
          { $set: { balance: { $add: [{ $ifNull: ['$balance', 500] }, win] }, lastSeenName: name, updatedAt: now, createdAt: { $ifNull: ['$createdAt', now] } } },
        ],
        { upsert: true }
      );
    }

    const result = win > 0 ? `${name} won $${win - bet} (payout $${win})` : `${name} lost $${bet}`;
    await chat.sendMessage(result);
  } finally {
    unlockGame(chatId);
  }
}

function delay(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
