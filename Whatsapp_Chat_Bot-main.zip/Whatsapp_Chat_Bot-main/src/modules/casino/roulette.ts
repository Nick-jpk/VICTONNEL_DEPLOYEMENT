import type { Message } from '../../services/whatsapp.js';
import { getDb } from '../../db/mongo.js';
import { lockGame, unlockGame } from '../gameLock.js';

type Bet = { userId: string; name: string; amount: number; kind: 'red'|'black'|'odd'|'even'|'number'; value?: number };

const sessions = new Map<string, { bets: Bet[]; timer?: NodeJS.Timeout }>();

export function isRouletteActive(chatId: string) { return sessions.has(chatId); }

export function cancelRoulette(chatId: string) {
  const s = sessions.get(chatId);
  if (!s) return;
  if (s.timer) clearTimeout(s.timer);
  sessions.delete(chatId);
  unlockGame(chatId);
}

export async function startRoulette(msg: Message) {
  const chat = await msg.getChat(); const chatId = chat.id._serialized;
  if (sessions.has(chatId)) { await msg.reply('Roulette already running.'); return; }
  lockGame(chatId);
  sessions.set(chatId, { bets: [] });
  await chat.sendMessage('🎡 Roulette started. 30s to bet. Format: bet 10 red|black|odd|even|0-36');
  const t = setTimeout(() => resolveRoulette(msg).catch(()=>{}), 30_000);
  sessions.get(chatId)!.timer = t;
}

export async function handleRouletteMessage(msg: Message) {
  const chat = await msg.getChat(); const chatId = chat.id._serialized; const s = sessions.get(chatId); if (!s) return;
  const body = (msg.body||'').trim();
  const m = body.match(/^bet\s+(\d+)\s+(red|black|odd|even|\d{1,2})$/i);
  if (!m) return;
  const amount = parseInt(m[1],10); if (amount<10) { await msg.reply('Min bet $10'); return; }
  const token = m[2].toLowerCase();
  let kind: Bet['kind']; let value: number|undefined;
  if (['red','black','odd','even'].includes(token)) kind = token as any; else { kind='number'; value=parseInt(token,10); if (value<0||value>36) { await msg.reply('Number must be 0-36'); return; } }
  const userId = (msg.author||msg.from) as string; const name = (await msg.getContact()).pushname||userId;
  const db = getDb(); const now = new Date();
  const pre = await db.collection('user_stats').findOne({ userId }, { projection: { balance:1 } });
  const balance = typeof pre?.balance==='number'?pre!.balance:500; if (balance<amount){ await msg.reply(`Insufficient funds ($${balance})`); return; }
  // hold bet by deducting now
  await db.collection('user_stats').updateOne({ userId },[
    { $set: { balance: { $subtract:[{ $ifNull:['$balance',500]}, amount]}, lastSeenName:name, updatedAt:now, createdAt:{ $ifNull:['$createdAt',now] } } }
  ],{ upsert:true });
  s.bets.push({ userId, name, amount, kind, value });
  await msg.reply(`Bet accepted: $${amount} on ${token}`);
}

function isRed(n:number){ return [1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36].includes(n); }

async function resolveRoulette(msg: Message) {
  const chat = await msg.getChat(); const chatId = chat.id._serialized; const s = sessions.get(chatId); if (!s){ return; }
  const n = Math.floor(Math.random()*37); const color = n===0? 'green' : (isRed(n)?'red':'black');
  const winners: { name:string; amount:number }[] = []; const losers: { name:string; amount:number }[] = [];
  const db = getDb(); const now = new Date();
  for (const b of s.bets) {
    let win = 0;
    if (b.kind==='red' && color==='red') win = b.amount*2;
    else if (b.kind==='black' && color==='black') win = b.amount*2;
    else if (b.kind==='odd' && n!==0 && (n%2===1)) win = b.amount*2;
    else if (b.kind==='even' && n!==0 && (n%2===0)) win = b.amount*2;
    else if (b.kind==='number' && b.value===n) win = b.amount*36;
    if (win>0) {
      await db.collection('user_stats').updateOne({ userId: b.userId },[
        { $set: { balance: { $add:[{ $ifNull:['$balance',500]}, win] }, lastSeenName:b.name, updatedAt:now, createdAt:{ $ifNull:['$createdAt',now] } } }
      ],{ upsert:true });
      winners.push({ name: b.name, amount: win - b.amount });
    } else {
      losers.push({ name: b.name, amount: b.amount });
    }
  }
  const lines: string[] = [];
  lines.push(`Roulette result: ${n} (${color})`);
  if (winners.length){ lines.push('', 'Winners:'); for (const w of winners) lines.push(`${w.name} +$${w.amount}`);} else lines.push('', 'No winners.');
  if (losers.length){ lines.push('', 'Losers:'); for (const l of losers) lines.push(`${l.name} -$${l.amount}`);} 
  await chat.sendMessage(lines.join('\n'));
  if (s.timer) clearTimeout(s.timer); sessions.delete(chatId); unlockGame(chatId);
}
