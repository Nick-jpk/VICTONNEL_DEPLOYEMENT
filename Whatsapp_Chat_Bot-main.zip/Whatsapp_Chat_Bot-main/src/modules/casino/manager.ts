import type { Message } from '../../services/whatsapp.js';
import { startRoulette, handleRouletteMessage, isRouletteActive, cancelRoulette } from './roulette.js';
import { startBlackjack, handleBlackjackMessage, isBlackjackActive, cancelBlackjack } from './blackjack.js';
import { startJackpot, handleJackpotMessage, isJackpotActive, cancelJackpot } from './jackpot.js';
import { startRroulette, handleRrouletteMessage, isRrouletteActive, cancelRroulette } from './rroulette.js';

export function isAnyCasinoActive(chatId: string): boolean {
  return isRouletteActive(chatId) || isBlackjackActive(chatId) || isJackpotActive(chatId) || isRrouletteActive(chatId);
}

export async function handleCasinoMessage(msg: Message) {
  const chat = await msg.getChat();
  const chatId = chat.id._serialized;
  if (isRouletteActive(chatId)) return handleRouletteMessage(msg);
  if (isBlackjackActive(chatId)) return handleBlackjackMessage(msg);
  if (isJackpotActive(chatId)) return handleJackpotMessage(msg);
  if (isRrouletteActive(chatId)) return handleRrouletteMessage(msg);
}

export { startRoulette, startBlackjack, startJackpot, startRroulette };

export function resetCasino(chatId: string){
  // Call cancel on all modules; they will no-op if not active
  try { cancelRoulette(chatId); } catch {}
  try { cancelBlackjack(chatId); } catch {}
  try { cancelJackpot(chatId); } catch {}
  try { cancelRroulette(chatId); } catch {}
}
