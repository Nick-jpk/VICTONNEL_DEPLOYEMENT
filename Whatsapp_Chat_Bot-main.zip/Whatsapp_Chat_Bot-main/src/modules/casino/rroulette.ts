import type { Message } from '../../services/whatsapp.js';
import { getDb } from '../../db/mongo.js';
import { lockGame, unlockGame } from '../gameLock.js';

type Player = { userId: string; name: string };
const ENTRY = 100;
const sessions = new Map<string, { players: Player[]; timer?: NodeJS.Timeout }>();

export function isRrouletteActive(chatId: string){ return sessions.has(chatId); }

export function cancelRroulette(chatId: string){
  const s = sessions.get(chatId);
  if (!s) return;
  if (s.timer) clearTimeout(s.timer);
  sessions.delete(chatId);
  unlockGame(chatId);
}

export async function startRroulette(msg: Message){
  const chat = await msg.getChat(); const chatId = chat.id._serialized; if (sessions.has(chatId)) { await msg.reply('Russian roulette already running.'); return; }
  lockGame(chatId);
  sessions.set(chatId, { players: [] });
  await chat.sendMessage('🔫 Russian Roulette started. 60s to join (type: join). Entry $100. Max 6 players. Dead players (1h) cannot join.');
  sessions.get(chatId)!.timer = setTimeout(()=>runRounds(msg).catch(()=>{}), 60_000);
}

export async function handleRrouletteMessage(msg: Message){
  const chat = await msg.getChat(); const chatId = chat.id._serialized; const s = sessions.get(chatId); if (!s) return;
  const body = (msg.body||'').trim().toLowerCase(); if (body!=='join') return;
  if (s.players.length>=6) { await msg.reply('Max 6 players.'); return; }
  const userId = (msg.author||msg.from) as string; const name = (await msg.getContact()).pushname||userId;
  if (s.players.find(p=>p.userId===userId)) { await msg.reply('Already joined.'); return; }
  const db = getDb(); const now = new Date();
  const pre = await db.collection('user_stats').findOne({ userId },{ projection:{ balance:1, deadUntil:1 }});
  const balance = typeof pre?.balance==='number'? pre!.balance:500;
  const deadUntil = pre?.deadUntil ? new Date(pre.deadUntil) : null;
  if (deadUntil && deadUntil > now) { await msg.reply('You are banned from RR for 24h (dead).'); return; }
  if (balance<ENTRY){ await msg.reply(`Insufficient funds ($${balance})`); return; }
  await db.collection('user_stats').updateOne({ userId },[{ $set:{ balance:{ $subtract:[{ $ifNull:['$balance',500]}, ENTRY]}, lastSeenName:name, updatedAt:now, createdAt:{ $ifNull:['$createdAt',now] } }}],{ upsert:true });
  s.players.push({ userId, name });
  await msg.reply(`${name} joined. (${s.players.length}/6)`);
}

async function runRounds(msg: Message){
  const chat = await msg.getChat(); const chatId = chat.id._serialized; const s = sessions.get(chatId); if (!s){ return; }
  let players = s.players.slice();
  if (players.length===0){ await chat.sendMessage('No players joined.'); cleanup(chatId); return; }
  const pot = players.length*ENTRY;
  if (players.length === 1) {
    await chat.sendMessage('Only one player joined. Taking up to 5 shots, revealed every 5 seconds...');
    const player = players[0];
    const db = getDb();
    const bullet = Math.floor(Math.random() * 6);
    for (let i = 0; i < 6; i++) {
      const shotNum = i + 1;
      if (i === bullet) {
        // Player dies; ban for 1 hour
        const deadUntil = new Date(Date.now() + 60 * 60 * 1000);
        await db.collection('user_stats').updateOne({ userId: player.userId }, { $set: { deadUntil } }, { upsert: true });
        await chat.sendMessage(`Shot ${shotNum}: 💥 ${player.name} is eliminated!`);
        cleanup(chatId);
        return;
      } else {
        await chat.sendMessage(`Shot ${shotNum}: click — ${player.name} survives.`);
        // Reveal pacing
        await new Promise((r) => setTimeout(r, 5000));
        if (shotNum === 5) break; // survive 5 shots to win
      }
    }
    // Survived 5 shots — award pot
    await db.collection('user_stats').updateOne(
      { userId: player.userId },
      [ { $set: { balance: { $add: [ { $ifNull: ['$balance', 500] }, pot ] } } } ],
      { upsert: true }
    );
    await chat.sendMessage(`🏆 ${player.name} survived 5 shots and wins +$${pot}`);
    cleanup(chatId);
    return;
  }
  await chat.sendMessage('Revealing eliminations every 5 seconds...');
  // Simulate rounds eliminating one until one left; single player must survive 5 shots
  let chamber = 6; let bullet = Math.floor(Math.random()*chamber); // conceptual
  const db = getDb();
  while (players.length>1) {
    const idx = Math.floor(Math.random()*players.length);
    const loser = players[idx];
    // mark dead 1h
    const deadUntil = new Date(Date.now()+60*60*1000);
    await db.collection('user_stats').updateOne({ userId: loser.userId },{ $set:{ deadUntil } },{ upsert:true });
    players.splice(idx,1);
    await chat.sendMessage(`💥 ${loser.name} is eliminated! Survivors: ${players.map(p=>p.name).join(', ')}`);
    // Slow down reveals to build suspense
    await new Promise(r=>setTimeout(r, 5000));
  }
  const winner = players[0];
  await db.collection('user_stats').updateOne({ userId: winner.userId },[{ $set:{ balance:{ $add:[{ $ifNull:['$balance',500]}, pot] } }}],{ upsert:true });
  await chat.sendMessage(`🏆 Winner: ${winner.name} +$${pot}`);
  cleanup(chatId);
}

function cleanup(chatId: string){
  const s = sessions.get(chatId); if (s?.timer) clearTimeout(s.timer);
  sessions.delete(chatId); unlockGame(chatId);
}
