declare module 'qrcode-terminal' {
  interface Options { small?: boolean }
  const qrcode: {
    generate(text: string, opts?: Options): void
  };
  export default qrcode;
}

