import dotenv from 'dotenv';
import path from 'node:path';

dotenv.config();

const cwd = process.cwd();

export const config = {
  port: Number(process.env.PORT || 3000),
  sessionDir: path.resolve(process.env.SESSION_DIR || path.join(cwd, 'storage', 'session')),
  allowedGroupId: (process.env.ALLOWED_GROUP_ID || '').trim(),
  mongoUri: (process.env.MONGODB_URI || '').trim(),
  mongoDb: (process.env.MONGODB_DB || 'whatsappbot').trim(),
};
