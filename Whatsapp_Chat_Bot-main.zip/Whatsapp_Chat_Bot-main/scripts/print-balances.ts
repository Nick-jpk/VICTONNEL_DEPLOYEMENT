import { connectMongo, getDb, closeMongo } from '../src/db/mongo.js';

async function main() {
  await connectMongo();
  const db = getDb();
  const docs = await db
    .collection('user_stats')
    .find({}, { projection: { userId: 1, balance: 1, _id: 0 } })
    .limit(5)
    .toArray();
  console.log(docs);
}

main()
  .catch((e) => {
    console.error(e);
    process.exitCode = 1;
  })
  .finally(async () => {
    await closeMongo().catch(() => {});
  });

