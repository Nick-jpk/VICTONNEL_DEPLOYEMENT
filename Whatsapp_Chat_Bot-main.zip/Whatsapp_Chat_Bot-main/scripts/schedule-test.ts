import 'dotenv/config';
import { getNextFixturesFD } from '../src/services/schedule/footballdata.js';

async function main() {
  console.log('FOOTBALL_DATA_TOKEN present:', Boolean(process.env.FOOTBALL_DATA_TOKEN));
  const out = await getNextFixturesFD();
  console.log('\n--- Next Matches (PKT) ---');
  console.log(out);
}

main().catch((err) => {
  console.error('Schedule test failed:', err);
  process.exit(1);
});

