import 'dotenv/config';
import { promises as fs } from 'node:fs';
import path from 'node:path';

type TweetMedia = { media_key: string; type: string; url?: string; preview_image_url?: string };

async function fetchJson(url: string, token: string) {
  const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
  if (!res.ok) {
    const body = await res.text().catch(() => '');
    throw new Error(`${res.status} ${res.statusText}: ${body.slice(0, 200)}`);
  }
  return res.json();
}

function nyTodayParts() {
  const fmt = new Intl.DateTimeFormat('en-US', {
    timeZone: 'America/New_York',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    timeZoneName: 'shortOffset',
  } as any);
  const parts = fmt.formatToParts(new Date()).reduce((acc: any, p) => { acc[p.type] = p.value; return acc; }, {} as any);
  const year = parts.year;
  const month = parts.month;
  const day = parts.day;
  const tz = parts.timeZoneName as string; // e.g., 'GMT-4'
  const m = tz && tz.match(/^GMT([+-])(\d{1,2})$/);
  let offset = '-04:00';
  if (m) {
    const sign = m[1];
    const hh = m[2].padStart(2, '0');
    offset = `${sign}${hh}:00`;
  }
  return { year, month, day, offset };
}

async function main() {
  const token = (process.env.TWITTER_BEARER_TOKEN || '').trim();
  const username = (process.env.CONTENT_USERNAME || 'easysbc_alerts').trim();
  if (!token) {
    console.error('Missing TWITTER_BEARER_TOKEN in .env');
    process.exit(1);
  }

  console.log('Testing X API with username:', username);

  // Optional: allow seeding cache without hitting API
  const seedArg = process.argv.find((a) => a.startsWith('--seed-url='));
  if (seedArg) {
    const url = seedArg.split('=')[1];
    if (!url) {
      console.error('Provide a URL: --seed-url=https://...jpg');
      process.exit(1);
    }
    const captionArg = process.argv.find((a) => a.startsWith('--caption='));
    const caption = captionArg ? captionArg.split('=')[1] : `@${username}`;
    console.log('Seeding cache from URL:', url);
    const r = await fetch(url);
    if (!r.ok) throw new Error(`Failed to download seed url: ${r.status}`);
    const arr = await r.arrayBuffer();
    const buf = Buffer.from(arr);
    const imageDir = path.join('storage', 'content');
    const imagePath = path.join(imageDir, 'latest.jpg');
    await fs.mkdir(imageDir, { recursive: true });
    await fs.writeFile(imagePath, buf);
    const cachePath = path.join('storage', 'content_cache.json');
    const meta = { username, imageUrl: url, imagePath, caption, tweetId: 'seed', t: Date.now() };
    await fs.writeFile(cachePath, JSON.stringify(meta, null, 2));
    console.log('\nSaved to:');
    console.log(' ', path.resolve(imagePath));
    console.log(' ', path.resolve(cachePath));
    return;
  }

  // 1) Resolve user id
  const user = await fetchJson(`https://api.twitter.com/2/users/by/username/${username}`, token);
  const userId = user?.data?.id as string | undefined;
  if (!userId) throw new Error('User not found');
  console.log('Resolved user id:', userId);

  // Define NY window: today 12:58–13:02 America/New_York
  const { year, month, day, offset } = nyTodayParts();
  const start = `${year}-${month}-${day}T12:58:00${offset}`;
  const end = `${year}-${month}-${day}T13:02:00${offset}`;
  console.log('Window (NY):', start, '→', end);

  // 2) Fetch recent tweets with media expansions
  const params = new URLSearchParams({
    exclude: 'retweets,replies',
    expansions: 'attachments.media_keys',
    'media.fields': 'url,preview_image_url,type',
    'tweet.fields': 'created_at',
    'start_time': start,
    'end_time': end,
    max_results: '25',
  });
  const tw = await fetchJson(`https://api.twitter.com/2/users/${userId}/tweets?${params.toString()}`, token);
  const tweets = (tw?.data || []) as Array<any>;
  const media = new Map<string, TweetMedia>();
  for (const m of (tw?.includes?.media || []) as TweetMedia[]) media.set(m.media_key, m);

  // Collect all photo media in window
  const items: Array<{ url: string; id: string; created_at?: string; text?: string }> = [];
  for (const t of tweets) {
    const keys: string[] = t?.attachments?.media_keys || [];
    for (const k of keys) {
      const m = media.get(k);
      if (m && m.type === 'photo' && m.url) {
        items.push({ url: m.url, id: t.id, created_at: t.created_at, text: t.text });
      }
    }
  }

  if (items.length === 0) {
    console.log('No image tweets found in the window.');
    return;
  }

  // Clear folder and write all images
  const imageDir = path.join('storage', 'content');
  await fs.mkdir(imageDir, { recursive: true });
  for (const f of await fs.readdir(imageDir)) {
    await fs.rm(path.join(imageDir, f), { force: true });
  }

  const cachePath = path.join('storage', 'content_cache.json');
  const imagesMeta: any[] = [];
  let idx = 1;
  for (const it of items) {
    try {
      const r = await fetch(it.url);
      if (!r.ok) continue;
      const arr = await r.arrayBuffer();
      const buf = Buffer.from(arr);
      const name = String(idx).padStart(2, '0') + '.jpg';
      const p = path.join(imageDir, name);
      await fs.writeFile(p, buf);
      imagesMeta.push({ path: p, url: it.url, caption: (it.text || '').trim(), tweetId: it.id, created_at: it.created_at });
      idx += 1;
    } catch {}
  }

  const uname = (process.env.CONTENT_USERNAME || 'easysbc_alerts').trim();
  const meta = { username: uname, t: Date.now(), images: imagesMeta };
  await fs.writeFile(cachePath, JSON.stringify(meta, null, 2));
  console.log(`Saved ${imagesMeta.length} image(s) to:`);
  console.log(' ', path.resolve(imageDir));
  console.log(' ', path.resolve(cachePath));
}

main().catch((err) => {
  console.error('X API test failed:', err);
  process.exit(1);
});
