import { connectMongo, getDb, closeMongo } from '../src/db/mongo.js';
import { logger } from '../src/utils/logger.js';

async function main() {
  await connectMongo();
  const db = getDb();
  const col = db.collection('user_stats');

  const now = new Date();

  // Add $1000 to all existing numeric balances.
  // If a doc has no numeric balance, set it to $1500.
  const res = await col.updateMany(
    {},
    [
      {
        $set: {
          balance: {
            $cond: [
              { $isNumber: '$balance' },
              { $add: ['$balance', 1000] },
              1500,
            ],
          },
          updatedAt: now,
          createdAt: { $ifNull: ['$createdAt', now] },
        },
      },
    ] as any
  );

  logger.info({ matched: res.matchedCount, modified: res.modifiedCount }, 'Updated user balances');
}

main()
  .catch((err) => {
    console.error('Balance update failed:', err);
    process.exitCode = 1;
  })
  .finally(async () => {
    await closeMongo().catch(() => {});
  });

